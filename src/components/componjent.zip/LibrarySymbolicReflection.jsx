import React, { useEffect, useState } from "react";
import axios from "axios";
import { useCaseContext } from "./CaseContext";

const TAGS = [
  "Cognitivo",
  "Emocional",
  "Somático",
  "Narrativo",
  "Outro"
];

export default function LibrarySymbolicReflection() {
  const { casePath } = useCaseContext() || {};
  const [entries, setEntries] = useState([]);
  const [selectedTags, setSelectedTags] = useState([]);

  // Fetch symbolic_summary.json
  useEffect(() => {
    if (!casePath) return;
    axios
      .post("http://localhost:5000/api/library/symbolic_summary", { case_path: casePath })
      .then(res => setEntries(res.data || []));
  }, [casePath]);

  const handleTagClick = (tag) => {
    setSelectedTags((prev) =>
      prev.includes(tag)
        ? prev.filter((t) => t !== tag)
        : [...prev, tag]
    );
  };

  // Filter entries by selectedTags (if any)
  const filtered = selectedTags.length === 0
    ? entries
    : entries.filter(e => e.tags && e.tags.some(tag => selectedTags.includes(tag)));

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white max-w-xl mx-auto">
      <h2 className="text-lg font-bold mb-2">Symbolic Reflection</h2>
      <div className="flex flex-wrap gap-2 mb-4">
        {TAGS.map((tag) => (
          <button
            key={tag}
            type="button"
            onClick={() => handleTagClick(tag)}
            className={`px-4 py-2 rounded ${
              selectedTags.includes(tag)
                ? "bg-blue-600 text-white border-2 border-blue-800"
                : "bg-gray-100 text-gray-800 border-gray-300 hover:bg-blue-100"
            }`}
          >
            {tag}
          </button>
        ))}
      </div>
      <div>
        <strong>Selecionadas:</strong> {selectedTags.join(", ") || "Nenhuma"}
      </div>
      <div className="mt-4 space-y-4">
        {filtered.length === 0 ? (
          <div className="text-gray-400 text-sm">No entries for these tags.</div>
        ) : (
          filtered.map((entry, idx) => (
            <div key={idx} className="border rounded p-2 bg-gray-50">
              <div className="text-xs text-gray-500 mb-1">
                {entry.timestamp ? new Date(entry.timestamp).toLocaleString() : ""}
                {entry.tags && entry.tags.length > 0 && (
                  <span className="ml-2">
                    {entry.tags.map(t => (
                      <span key={t} className="inline-block px-2 py-0.5 bg-blue-200 text-blue-900 rounded mr-1 text-xxs">{t}</span>
                    ))}
                  </span>
                )}
                {entry.source && (
                  <span className="ml-2 text-yellow-600">[{entry.source}]</span>
                )}
              </div>
              <div>{entry.text || entry.content || entry.summary || "—"}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
