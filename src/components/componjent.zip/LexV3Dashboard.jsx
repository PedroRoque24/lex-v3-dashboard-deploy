import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip } from "@/components/ui/tooltip";
import { Card, CardContent } from "@/components/ui/card";
import Sidebar from "./ui/Sidebar";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";

import CaseDropdown from "./CaseDropdown";
import { useCaseContext } from "./CaseContext";

import SymbolicMode from "./SymbolicMode";
import PatientInputBlock from "./PatientInputBlock";
import PatientAnamnesisBlock from "./PatientAnamnesisBlock";
import LexReasoningPanel from "./LexReasoningPanel";
import LexBrainOutputPanel from "./LexBrainOutputPanel";
import TeachingPanel from "./TeachingPanel";
import DownloadPatientReportButton from "./DownloadPatientReportButton";
import ReportHistoryViewer from "./ReportHistoryViewer";
import MoodTracker from "./MoodTracker";
import VitalsInputBlock from "./VitalsInputBlock";
import VitalsLogViewer from "./VitalsLogViewer";
import VitalsTrendGraph from "./VitalsTrendGraph";
import ExamIntakeBlock from "./ExamIntakeBlock";
import ExamViewer from "./ExamViewer";
import JournalInputBlock from "./JournalInputBlock";
import JournalLogViewer from "./JournalLogViewer";
import EmotionalLogViewer from "./EmotionalLogViewer";
import EmotionalSummaryViewer from "./EmotionalSummaryViewer";
import ContinuumTimelineViewer from "./ContinuumTimelineViewer";
import ContinuumAlertsViewer from "./ContinuumAlertsViewer";
import CompanionPromptViewer from "./CompanionPromptViewer";
import CompanionEmotionHistoryViewer from "./CompanionEmotionHistoryViewer";
import MedicationInputBlock from "./MedicationInputBlock";
import MedicationViewer from "./MedicationViewer";
import MedicationLogViewer from "./MedicationLogViewer";
import UpcomingMedicationViewer from "./UpcomingMedicationViewer";
import EmotionTrendChart from "./EmotionTrendChart";
import WeeklyEmotionDigestViewer from "./WeeklyEmotionDigestViewer";
import VisionUploader from "./VisionUploader";
import PDFExamUploader from "./PDFExamUploader";
import ContinuumHealthTools from "./ContinuumHealthTools";
import WellnessTrackerV2 from "./WellnessTrackerV2";
import TranscribeAndDisplayBox from './TranscribeAndDisplayBox';
import LexReportViewer from './LexReportViewer';

import UniversalTranscriberBox from "./UniversalTranscriberBox";

import ActiveProblemsPanel from "./ActiveProblemsPanel";

// === Library components ===
import LibraryReportGenerator from "./LibraryReportGenerator";
import LibraryExternalExport from "./LibraryExternalExport";
import LibraryDocumentReader from "./LibraryDocumentReader";
import LibraryCertificateArchive from "./LibraryCertificateArchive";
import LibraryEditorSnippets from "./LibraryEditorSnippets";
import LibraryKnowledgeJournal from "./LibraryKnowledgeJournal";
import LibraryTimelineNavigator from "./LibraryTimelineNavigator";
import LibrarySymbolicReflection from "./LibrarySymbolicReflection";
import LibraryTranscriber from "./LibraryTranscriber";

// === Public Health components ===
import PublicGeoMapping from "./PublicGeoMapping";
import PublicOutbreakReport from "./PublicOutbreakReport";
import PublicPrevalenceCalculator from "./PublicPrevalenceCalculator";
import PublicSymptomSurveillance from "./PublicSymptomSurveillance";
import PublicTrendTracker from "./PublicTrendTracker";

// === Chronic Disease/Medication blocks ===
import ChronicDiseaseBlock from "./ChronicDiseaseBlock";
import ChronicMedicationBlock from "./ChronicMedicationBlock";

// === Lex Avatar ===
import LexBurningBush from "./LexBurningBush";

// --- Multi-Open Accordion Section Helper ---
function AccordionSection({ title, section, openSections, onToggle, children, icon, borderColor = "purple" }) {
  const isOpen = openSections.includes(section);
  const border =
    borderColor === "blue"
      ? "border-blue-700"
      : borderColor === "gray"
      ? "border-gray-700"
      : "border-purple-700";
  const accent =
    borderColor === "blue"
      ? "bg-blue-900 text-blue-200"
      : borderColor === "gray"
      ? "bg-gray-800 text-white"
      : "bg-fuchsia-900 text-fuchsia-200";

  return (
    <div className={`mb-6 rounded-2xl shadow-lex`}>
      <button
        className={`w-full flex items-center justify-between px-6 py-4 text-lg font-bold rounded-2xl border-2 ${border} ${
          isOpen
            ? `${accent} shadow-lex`
            : "bg-lex-card border-lex-accent/30 text-white hover:bg-lex-accent/20"
        } transition-all`}
        onClick={() => onToggle(section)}
      >
        <span>
          {icon && <span className="mr-2 text-2xl align-middle">{icon}</span>}
          {title}
        </span>
        <span className="ml-3 text-xl">{isOpen ? "▲" : "▼"}</span>
      </button>
      {isOpen && (
        <div
          className={`rounded-b-2xl p-6 border-t-2 ${border} bg-gray-900/80 animate-fadeIn`}
          style={{ marginTop: "-2px" }}
        >
          {children}
        </div>
      )}
    </div>
  );
}

// === LiveLex Tab: ShadowBrain Real-Time Chat ===
function LiveLexChat() {
  const [messages, setMessages] = useState([
    { from: "lex", text: "Hello Pedro. I am here. Speak to me about anything, any time." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessages = [...messages, { from: "you", text: input.trim() }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/shadowbrain/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input.trim() }),
      });
      const data = await res.json();
      setMessages(msgs =>
        [...msgs, { from: "lex", text: data.reply || "..." }]
      );
    } catch {
      setMessages(msgs =>
        [...msgs, { from: "lex", text: "ShadowBrain is unavailable at the moment." }]
      );
    }
    setLoading(false);
  };

  const handleInput = (e) => {
    setInput(e.target.value);
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <div
      className="flex flex-col min-h-[80vh] w-full"
      style={{
        background: "#070818",
        minHeight: "calc(100vh - 60px)",
        padding: 0,
        margin: 0,
        position: "relative",
        color: "#fff",
        overflow: "hidden"
      }}
    >
      <div className="flex flex-col items-center justify-center pt-10 pb-4">
        <LexBurningBush size={300} />
        <div className="text-3xl font-extrabold text-fuchsia-400 mt-6">
          LiveLex – ShadowBrain Real-Time Chat
        </div>
      </div>
      <div className="flex-1 overflow-y-auto px-0 sm:px-8 py-4">
        <div className="flex flex-col gap-4 max-w-2xl mx-auto">
          {messages.map((m, i) => (
            <div
              key={i}
              className={`flex ${m.from === "you" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`rounded-2xl px-5 py-3 text-base max-w-[80%] shadow-lg
                  ${m.from === "you"
                    ? "bg-fuchsia-700 text-white self-end"
                    : "bg-[#16172c] text-fuchsia-200 border border-fuchsia-700 self-start"}`}
                style={{
                  fontWeight: m.from === "lex" ? "bold" : "normal",
                  fontSize: m.from === "lex" ? "1.12rem" : "1rem"
                }}
              >
                {m.text}
              </div>
            </div>
          ))}
          <div ref={bottomRef}></div>
        </div>
      </div>
      <form
        className="w-full px-0 sm:px-8 py-4 flex justify-center bg-[#070818] border-t border-fuchsia-700"
        onSubmit={e => {
          e.preventDefault();
          sendMessage();
        }}
      >
        <input
          className="flex-1 bg-[#18192b] rounded-2xl p-3 text-white outline-none mr-2 text-base border border-fuchsia-600"
          placeholder="Speak to Lex..."
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleInput}
          disabled={loading}
        />
        <button
          type="submit"
          className="bg-fuchsia-700 text-white px-6 py-2 rounded-2xl font-bold shadow-fuchsia-500/20"
          disabled={loading || !input.trim()}
        >
          {loading ? "..." : "Send"}
        </button>
      </form>
    </div>
  );
}

// === CONTINUUM CONTENT HELPER ===
function ContinuumContent() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4">
      <div className="md:col-span-2">
        <ActiveProblemsPanel casePath={useCaseContext()?.casePath || ""} />
      </div>
      <div className="md:col-span-2 text-right">
        <DownloadPatientReportButton />
      </div>
      <div className="md:col-span-2"><ReportHistoryViewer /></div>
      <MoodTracker />
      <VitalsInputBlock />
      <VitalsLogViewer />
      <VitalsTrendGraph casePath={useCaseContext()?.casePath || "default"} />
      <ExamIntakeBlock />
      <ExamViewer />
      <Card>
        <CardContent>
          <h2 className="text-xl font-semibold">Journal</h2>
          <p>Patient reflections</p>
        </CardContent>
      </Card>
      <div className="md:col-span-2"><JournalInputBlock /><JournalLogViewer /></div>
      <div className="md:col-span-2"><EmotionalLogViewer /></div>
      <div className="md:col-span-2"><EmotionalSummaryViewer /></div>
      <div className="md:col-span-2"><ContinuumTimelineViewer /></div>
      <div className="md:col-span-2"><ContinuumAlertsViewer /></div>
      <div className="md:col-span-2"><CompanionPromptViewer /></div>
      <div className="md:col-span-2"><CompanionEmotionHistoryViewer /></div>
      <div className="md:col-span-2"><MedicationInputBlock /></div>
      <div className="md:col-span-2"><MedicationViewer /></div>
      <div className="md:col-span-2"><MedicationLogViewer /></div>
      <div className="md:col-span-2"><UpcomingMedicationViewer /></div>
      <div className="md:col-span-2"><EmotionTrendChart /></div>
      <div className="md:col-span-2"><WeeklyEmotionDigestViewer /></div>
      <div className="md:col-span-2"><ContinuumHealthTools /></div>
      <div className="md:col-span-2"><WellnessTrackerV2 /></div>
      <div className="md:col-span-2"><ChronicDiseaseBlock /></div>
      <div className="md:col-span-2"><ChronicMedicationBlock /></div>
    </div>
  );
}

// === CLINICAL MODE COLLAPSIBLE PANEL ===
function ClinicalModePage(props) {
  const {
    patientData, setPatientData,
    consentToUseName, setConsentToUseName,
    patientName, setPatientName,
    isLoading, handleRunReasoning,
    lexBrainOutput, setLexBrainOutput,
    discussionInput, setDiscussionInput,
    discussionReply, handleSubmitDiscussion,
    quickQuestion, setQuickQuestion,
    qaReply, handleSubmitQuestion
  } = props;

  // Allow multiple sections open
  const [openSections, setOpenSections] = useState(["uploads"]);
  const toggleSection = (section) =>
    setOpenSections((prev) =>
      prev.includes(section)
        ? prev.filter((s) => s !== section)
        : [...prev, section]
    );

  return (
    <div className="max-w-5xl mx-auto mt-4">
      {/* Uploads */}
      <AccordionSection
        title="Upload Medical Image for AI Review"
        section="uploads"
        openSections={openSections}
        onToggle={toggleSection}
        icon="🖼️"
        borderColor="blue"
      >
        <VisionUploader showTitle={false} />
      </AccordionSection>
      <AccordionSection
        title="Upload PDF Exam/Lab Results for AI Review"
        section="uploads_pdf"
        openSections={openSections}
        onToggle={toggleSection}
        icon="📄"
        borderColor="blue"
      >
        <PDFExamUploader showTitle={false} />
      </AccordionSection>

      {/* Patient Input */}
      <AccordionSection
        title="Patient Input"
        section="patientinput"
        openSections={openSections}
        onToggle={toggleSection}
        icon="🧾"
        borderColor="gray"
      >
        <div className="bg-gray-900 border border-blue-700 rounded-xl p-5 text-white">
          <PatientInputBlock patientData={patientData} setPatientData={setPatientData} />
        </div>
      </AccordionSection>

      {/* Clinical History */}
      <AccordionSection
        title="Clinical History & Context"
        section="anamnesis"
        openSections={openSections}
        onToggle={toggleSection}
        icon="📝"
        borderColor="gray"
      >
        <div className="bg-gray-900 border border-purple-700 rounded-xl p-5 text-white">
          <PatientAnamnesisBlock patientData={patientData} setPatientData={setPatientData} />
        </div>
      </AccordionSection>

      {/* Transcribers */}
      <AccordionSection
        title="Transcription & Summary"
        section="transcriber"
        openSections={openSections}
        onToggle={toggleSection}
        icon="🎙️"
        borderColor="gray"
      >
        <div className="bg-gray-900 border border-blue-700 rounded-xl p-5 text-white">
          <TranscribeAndDisplayBox setPatientData={setPatientData} />
          <UniversalTranscriberBox />
        </div>
      </AccordionSection>

      {/* Consent & Name */}
      <AccordionSection
        title="Consent & Patient Name"
        section="consent"
        openSections={openSections}
        onToggle={toggleSection}
        icon="📝"
        borderColor="gray"
      >
        <div className="bg-gray-900 border border-purple-700 rounded-xl p-5 text-white">
          <label className="inline-flex items-center space-x-2">
            <input
              type="checkbox"
              checked={consentToUseName}
              onChange={(e) => setConsentToUseName(e.target.checked)}
            />
            <span>Save with real patient name</span>
          </label>
          {consentToUseName && (
            <input
              type="text"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              placeholder="Enter patient name"
              className="ml-4 px-2 py-1 text-black rounded"
            />
          )}
        </div>
      </AccordionSection>

      {/* Run LexBrain Reasoning */}
      <AccordionSection
        title="Run LexBrain Reasoning"
        section="runreasoning"
        openSections={openSections}
        onToggle={toggleSection}
        icon="⚡"
        borderColor="purple"
      >
        <div className="text-center py-2">
          <Button
            onClick={handleRunReasoning}
            className="bg-fuchsia-700 hover:bg-fuchsia-800 text-white px-6 py-3 rounded-2xl text-lg shadow-lex"
          >
            {isLoading ? "Thinking..." : "Run LexBrain Reasoning"}
          </Button>
        </div>
      </AccordionSection>

      {/* LexBrain Output & Doctor Feedback */}
      <AccordionSection
        title="LexBrain Reasoning Output & Doctor Feedback"
        section="output"
        openSections={openSections}
        onToggle={toggleSection}
        icon="🧠"
        borderColor="purple"
      >
        <div className="bg-gray-900 border border-purple-700 rounded-xl p-5 text-white">
          <LexBrainOutputPanel summary={lexBrainOutput} />
        </div>
      </AccordionSection>

      {/* Report Export */}
      <AccordionSection
        title="Download/Export Reasoning & SOAP"
        section="report"
        openSections={openSections}
        onToggle={toggleSection}
        icon="📥"
        borderColor="purple"
      >
        {(lexBrainOutput?.summary_raw || lexBrainOutput?.summary) ? (
          <div className="bg-gray-900 border border-blue-700 rounded-xl p-5 text-white">
            <LexReportViewer
              lexOutput={lexBrainOutput?.summary_raw || lexBrainOutput?.summary || ""}
              casePath={lexBrainOutput?.case_path}
              patientId={patientData?.name}
            />
          </div>
        ) : (
          <div className="text-yellow-400 text-lg py-4">
            ⚠️ Run LexBrain Reasoning above to unlock export/download options.
          </div>
        )}
      </AccordionSection>

      {/* Medical Discussion */}
      <AccordionSection
        title="Medical Discussion"
        section="discussion"
        openSections={openSections}
        onToggle={toggleSection}
        icon="💬"
        borderColor="purple"
      >
        <div className="bg-gray-900 border border-purple-700 rounded-xl p-5">
          <h3 className="text-xl font-bold text-purple-300 mb-2">🧠 Medical Discussion</h3>
          <textarea
            placeholder="Ask Lex why he made certain decisions..."
            className="w-full bg-black border border-purple-600 text-white p-3 rounded-md"
            rows="4"
            value={discussionInput}
            onChange={(e) => setDiscussionInput(e.target.value)}
          />
          <button
            onClick={handleSubmitDiscussion}
            className="bg-purple-700 text-white mt-2 px-4 py-2 rounded"
          >
            Ask About Lex's Reasoning
          </button>
          {discussionReply && (
            <div className="prose prose-invert bg-black text-green-300 p-4 mt-4 rounded border border-green-800 max-h-72 overflow-y-auto">
              {discussionReply.split("\n").map((line, idx) => (
                <p key={idx}>{line}</p>
              ))}
            </div>
          )}
        </div>
      </AccordionSection>

      {/* Quick Clinical Question */}
      <AccordionSection
        title="Quick Clinical Question"
        section="quickq"
        openSections={openSections}
        onToggle={toggleSection}
        icon="❓"
        borderColor="blue"
      >
        <div className="bg-gray-900 border border-blue-700 rounded-xl p-5">
          <h3 className="text-xl font-bold text-blue-300 mb-2">💬 Quick Clinical Question</h3>
          <input
            type="text"
            placeholder="e.g. Is azithromycin safe in pregnancy?"
            className="w-full bg-black border border-blue-600 text-white p-3 rounded-md"
            value={quickQuestion}
            onChange={(e) => setQuickQuestion(e.target.value)}
          />
          <button
            onClick={handleSubmitQuestion}
            className="bg-blue-700 text-white mt-2 px-4 py-2 rounded"
          >
            Ask Lex
          </button>
          {qaReply && (
            <div className="prose prose-invert bg-black text-blue-200 p-4 mt-4 rounded border border-blue-600 max-h-72 overflow-y-auto">
              {qaReply.split("\n").map((line, idx) => (
                <p key={idx}>{line}</p>
              ))}
            </div>
          )}
        </div>
      </AccordionSection>
    </div>
  );
}

// =============
// MAIN FUNCTION
// =============
export default function LexV3Dashboard() {
  const [discussionInput, setDiscussionInput] = useState("");
  const [discussionReply, setDiscussionReply] = useState("");
  const [quickQuestion, setQuickQuestion] = useState("");
  const [qaReply, setQaReply] = useState("");

  const [patientData, setPatientData] = useState({
    respiratoryRate: "",
    name: "",
    age: "",
    sex: "",
    heartRate: "",
    bloodPressure: "",
    temperature: "",
    oxygenSaturation: "",
    weight: "",
    height: "",
    anamnesis: "",
    medications: "",
    chronicConditions: "",
    allergies: "",
    familyHistory: "",
    examsAndLabs: "",
    physicalExam: "",
    substanceUse: "",
    rawInput: "",
    useRawInput: false
  });

  const [lexBrainOutput, setLexBrainOutput] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [consentToUseName, setConsentToUseName] = useState(false);
  const [patientName, setPatientName] = useState("");

  const handleSubmitDiscussion = async () => {
    if (!discussionInput || !lexBrainOutput?.summary_raw) return;
    try {
      const res = await fetch("/api/clinical/discuss", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: discussionInput,
          lex_output: lexBrainOutput.summary_raw || lexBrainOutput.summary || ""
        })
      });
      const data = await res.json();
      setDiscussionReply(data.reply || "No response.");
    } catch (err) {
      setDiscussionReply("Lex is unavailable.");
    }
  };

  const handleSubmitQuestion = async () => {
    if (!quickQuestion) return;
    try {
      const res = await fetch("/api/clinical/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: quickQuestion })
      });
      const data = await res.json();
      setQaReply(data.answer || "No response.");
    } catch (err) {
      setQaReply("Lex is unavailable.");
    }
  };

  const handleRunReasoning = async () => {
    if (!patientData.useRawInput && patientData.rawInput) {
      setPatientData(prev => ({ ...prev, useRawInput: true }));
    }
    setIsLoading(true);
    try {
      const response = await fetch("http://127.0.0.1:5001/api/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
              ...patientData,
              name: patientName,
              consentToUseName: consentToUseName,
              patient_id: "fallback_if_missing"
            })
      });
      const result = await response.json();
      setLexBrainOutput(result);
    } catch (error) {
      console.error("LexBrain fetch error:", error);
      setLexBrainOutput({ error: "Failed to reach LexBrain API." });
    }
    setIsLoading(false);
  };

  return (
    <Router>
      <div className="flex min-h-screen">
        <Sidebar />
        <main className="flex-1 p-6 dashboard-bg space-y-6">
          <h1 className="text-4xl font-bold">🧠 Lex V3 Interface</h1>
          <CaseDropdown />
          {useCaseContext()?.casePath && (
            <p className="text-sm text-gray-500 mb-4">
              Selected: <code>{useCaseContext().casePath}</code>
            </p>
          )}
          <Routes>
            <Route path="/symbolic" element={<SymbolicMode />} />
            <Route
              path="/clinical"
              element={
                <ClinicalModePage
                  patientData={patientData}
                  setPatientData={setPatientData}
                  consentToUseName={consentToUseName}
                  setConsentToUseName={setConsentToUseName}
                  patientName={patientName}
                  setPatientName={setPatientName}
                  isLoading={isLoading}
                  handleRunReasoning={handleRunReasoning}
                  lexBrainOutput={lexBrainOutput}
                  setLexBrainOutput={setLexBrainOutput}
                  discussionInput={discussionInput}
                  setDiscussionInput={setDiscussionInput}
                  discussionReply={discussionReply}
                  handleSubmitDiscussion={handleSubmitDiscussion}
                  quickQuestion={quickQuestion}
                  setQuickQuestion={setQuickQuestion}
                  qaReply={qaReply}
                  handleSubmitQuestion={handleSubmitQuestion}
                />
              }
            />
            <Route path="/continuum/doctor" element={<ContinuumContent />} />
            <Route path="/continuum/patient" element={<ContinuumContent />} />
            <Route
              path="/library"
              element={
                <div className="space-y-6">
                  <LibraryReportGenerator />
                  <LibraryExternalExport />
                  <LibraryDocumentReader />
                  <LibraryCertificateArchive />
                  <LibraryEditorSnippets />
                  <LibraryKnowledgeJournal />
                  <LibraryTimelineNavigator />
                  <LibrarySymbolicReflection />
                  <LibraryTranscriber />
                </div>
              }
            />
            <Route
              path="/public-health/outbreak"
              element={
                <div className="space-y-6">
                  <PublicGeoMapping />
                  <PublicOutbreakReport />
                  <PublicPrevalenceCalculator />
                  <PublicSymptomSurveillance />
                  <PublicTrendTracker />
                </div>
              }
            />
            <Route
              path="/simulation"
              element={
                <div className="grid grid-cols-1">
                  <TeachingPanel />
                </div>
              }
            />
            <Route path="/livelex" element={<LiveLexChat />} />
            <Route path="*" element={<Navigate to="/symbolic" />} />
          </Routes>
          {/* AVATAR: Floating Burning Bush */}
          <div
            style={{
              position: "fixed",
              right: "32px",
              bottom: "32px",
              zIndex: 2000,
              pointerEvents: "none",
              opacity: 1
            }}
          >
            <LexBurningBush size={260} />
          </div>
          <div className="fixed bottom-4 right-4">
            <Tooltip content="Toolbox / Options">
              <Button className="rounded-full bg-gray-800 w-12 h-12">⋮</Button>
            </Tooltip>
          </div>
        </main>
      </div>
    </Router>
  );
}

