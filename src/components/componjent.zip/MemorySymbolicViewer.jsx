import React, { useEffect, useState } from "react";

export default function MemorySymbolicViewer() {
  const [memory, setMemory] = useState(null);

  useEffect(() => {
    fetch("/memory/long_memory_index.json")
      .then((res) => res.json())
      .then((data) => {
        // Only use latest non-null, meaningful entry
        const latest = (data || []).slice().reverse().find(entry =>
          entry && entry.symbol && entry.symbol !== "(unspecified)"
        );
        setMemory(latest || null);
      })
      .catch(() => setMemory(null));
  }, []);

  return (
    <div className="p-4 rounded-xl shadow bg-white text-black space-y-4">
      <h2 className="text-xl font-bold text-blue-700">🧠 Latest Symbolic Memory</h2>
      {!memory ? (
        <p className="text-gray-500 italic">No memory entries available.</p>
      ) : (
        <div className="border border-gray-300 rounded-lg p-3 bg-gray-50 shadow-sm">
          <p><strong>Type:</strong> {memory.type || "Unknown"}</p>
          <p><strong>Symbol:</strong> {memory.symbol}</p>
          <p><strong>Valence:</strong> {memory.valence ?? "Not specified"}</p>
          <p><strong>Clarity:</strong> {memory.clarity ?? "Not specified"}</p>
          <p className="text-sm text-gray-600 mt-1">🕒 {memory.timestamp || "Unknown time"}</p>
        </div>
      )}
    </div>
  );
}
