import React, { useState, useEffect } from "react";
import axios from "axios";
import { useCaseContext } from "./CaseContext";

export default function LibraryExternalExport() {
  const { casePath } = useCaseContext() || {};
  const [tab, setTab] = useState("export");
  const [files, setFiles] = useState([]);
  const [savedCerts, setSavedCerts] = useState([]);
  const [selected, setSelected] = useState(null);

  // Load certs on tab/case switch
  useEffect(() => {
    if (tab === "archive" && casePath) {
      axios.post("http://localhost:5000/api/certificates/get", { case_path: casePath })
        .then(res => setSavedCerts(res.data || []));
    }
  }, [tab, casePath]);

  // Save uploaded file to backend
  const handleFileSelect = async (e) => {
    const filesArr = Array.from(e.target.files);
    setFiles((prev) => [...prev, ...filesArr]);
    if (!casePath) return;
    for (let file of filesArr) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        await axios.post("http://localhost:5000/api/certificates/add", {
          case_path: casePath,
          name: file.name,
          content: event.target.result,
        });
      };
      reader.readAsText(file);
    }
    // Refresh archive after upload
    const res = await axios.post("http://localhost:5000/api/certificates/get", { case_path: casePath });
    setSavedCerts(res.data || []);
  };

  // Download all in-memory uploaded files (not archived ones)
  const downloadAll = () => {
    files.forEach((file) => {
      const link = document.createElement("a");
      link.href = URL.createObjectURL(file);
      link.download = file.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  };

  // Attach cert to patient case (again, saved in backend as attached_certificates.json)
  const handleAttach = async () => {
    if (!selected || !casePath) return;
    await axios.post("http://localhost:5000/api/certificates/attach", {
      case_path: casePath,
      name: selected.name,
      content: selected.content,
    });
    alert("Certificate attached to patient case.");
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div className="flex gap-2 mb-4">
        <button
          className={`px-4 py-2 rounded-t ${tab === "export" ? "bg-blue-700 text-white" : "bg-gray-200"}`}
          onClick={() => setTab("export")}
          type="button"
        >
          📤 External Export
        </button>
        <button
          className={`px-4 py-2 rounded-t ${tab === "archive" ? "bg-blue-700 text-white" : "bg-gray-200"}`}
          onClick={() => setTab("archive")}
          type="button"
        >
          📁 Saved Certificates
        </button>
      </div>

      {tab === "export" && (
        <div>
          <h2 className="text-xl font-bold">External Export Mode</h2>
          <input
            type="file"
            multiple
            accept=".txt,.pdf,.doc,.docx"
            onChange={handleFileSelect}
            className="block w-full"
          />
          {files.length > 0 && (
            <div className="space-y-2 mt-2">
              <h3 className="text-md font-semibold">Selected Files:</h3>
              <ul className="list-disc pl-5 text-sm">
                {files.map((f, i) => (
                  <li key={i}>{f.name}</li>
                ))}
              </ul>
              <button
                onClick={downloadAll}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                type="button"
              >
                ⬇️ Download All
              </button>
            </div>
          )}
        </div>
      )}

      {tab === "archive" && (
        <div>
          <h2 className="text-xl font-bold mb-2">Saved Certificates</h2>
          <ul className="space-y-2">
            {savedCerts.map((r, idx) => (
              <li key={idx}>
                <button
                  className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                  onClick={() => setSelected(r)}
                  type="button"
                >
                  📄 {r.name}
                </button>
              </li>
            ))}
          </ul>
          {selected && (
            <div className="mt-4">
              <h3 className="font-semibold mb-2">Preview: {selected.name}</h3>
              <textarea
                rows={12}
                className="w-full border rounded p-2 text-sm"
                value={selected.content}
                readOnly
              />
              <button
                className="mt-2 bg-green-600 text-white px-4 py-2 rounded"
                onClick={handleAttach}
                type="button"
              >
                📎 Attach to Patient Case
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

