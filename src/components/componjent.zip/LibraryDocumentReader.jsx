import React, { useState } from "react";
// These must be installed via npm/yarn and available in your build!
import mammoth from "mammoth";
import Tesseract from "tesseract.js";

export default function LibraryDocumentReader() {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [filename, setFilename] = useState("");

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setFilename(file.name);
    setLoading(true);

    try {
      if (file.type === "application/pdf") {
        // PDF.js - must be loaded globally, see setup below
        const pdfjsLib = window["pdfjs-dist/build/pdf"];
        pdfjsLib.GlobalWorkerOptions.workerSrc =
          "//cdnjs.cloudflare.com/ajax/libs/pdf.js/2.6.347/pdf.worker.min.js";
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        let fullText = "";
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const txt = await page.getTextContent();
          fullText += txt.items.map(item => item.str).join(" ") + "\n";
        }
        setText(fullText);
      } else if (
        file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
        file.name.endsWith(".docx")
      ) {
        // Mammoth.js for docx
        const arrayBuffer = await file.arrayBuffer();
        const { value } = await mammoth.extractRawText({ arrayBuffer });
        setText(value);
      } else if (
        file.type.startsWith("image/") ||
        file.name.match(/\.(png|jpg|jpeg)$/i)
      ) {
        // OCR with Tesseract.js
        const url = URL.createObjectURL(file);
        const { data: { text: ocrText } } = await Tesseract.recognize(url, "eng");
        setText(ocrText);
        URL.revokeObjectURL(url);
      } else if (
        file.type === "text/plain" ||
        file.type === "text/markdown" ||
        file.type === "application/json" ||
        file.name.match(/\.(txt|md|json|csv|log)$/i)
      ) {
        // Simple text files
        const raw = await file.text();
        setText(raw);
      } else {
        setText("Unsupported file type.");
      }
    } catch (err) {
      setText("Error parsing file: " + err.message);
    }
    setLoading(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div>
        <h2 className="text-xl font-bold">Document Reader</h2>
        <input
          type="file"
          accept=".txt,.md,.json,.csv,.log,.pdf,.docx,.png,.jpg,.jpeg"
          onChange={handleFileUpload}
          className="block w-full"
        />
        {loading && (
          <div className="my-2 text-blue-500">Extracting text... (PDF, OCR, or DOCX may take a few seconds)</div>
        )}
        {text && (
          <>
            <h4 className="mt-2 mb-1 font-semibold text-sm">{filename}</h4>
            <textarea
              value={text}
              onChange={e => setText(e.target.value)}
              rows={14}
              className="w-full border p-2 text-sm rounded"
            />
            <button
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition mt-2"
              onClick={handleCopy}
              type="button"
            >
              📋 Copy Extracted Text
            </button>
          </>
        )}
      </div>
    </div>
  );
}

