import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext.jsx";

const MedicationLogViewer = () => {
  const { casePath } = useCaseContext();
  const [meds, setMeds] = useState([]);
  const [log, setLog] = useState([]);
  const [status, setStatus] = useState({});

  useEffect(() => {
    if (!casePath) return;

    fetch("http://localhost:5000/api/medications/get", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath })
    })
      .then((res) => res.json())
      .then((data) => setMeds(data || []));

    fetch("http://localhost:5000/api/medications/log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath })
    })
      .then((res) => res.json())
      .then((data) => {
        const tracker = {};
        data.forEach((entry) => {
          tracker[entry.medication] = entry.status || "taken";
        });
        setStatus(tracker);
      });
  }, [casePath]);

  const mark = async (medication, state) => {
    await fetch("http://localhost:5000/api/medications/" + state, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath, medication })
    });
    setStatus({ ...status, [medication]: state });
  };

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4">
      <h2 className="text-xl font-bold mb-2">📒 Medication Log Viewer</h2>
      <ul className="space-y-3">
        {meds.map((med, i) => (
          <li key={i} className="border-b pb-2">
            <strong>{med.name}</strong> – {med.dose} (every {med.frequency_hours}h)<br />
            {status[med.name] === "taken" && <span className="text-green-600 text-sm">✅ Taken</span>}
            {status[med.name] === "missed" && <span className="text-red-600 text-sm">❌ Missed</span>}
            {!status[med.name] && (
              <>
                <button
                  onClick={() => mark(med.name, "taken")}
                  className="mt-1 px-3 py-1 bg-green-600 text-white rounded mr-2 text-xs"
                >
                  ✅ Mark as Taken
                </button>
                <button
                  onClick={() => mark(med.name, "missed")}
                  className="mt-1 px-3 py-1 bg-red-600 text-white rounded text-xs"
                >
                  ❌ Mark as Missed
                </button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MedicationLogViewer;