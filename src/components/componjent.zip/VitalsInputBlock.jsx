import React, { useState, useEffect } from "react";
import { useCaseContext } from "./CaseContext";

export default function VitalsInputBlock() {
  const { casePath } = useCaseContext();
  const [vitals, setVitals] = useState({
    temperature: "",
    bp: "",
    heartRate: "",
    o2Sat: ""
  });

  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (casePath) setReady(true);
  }, [casePath]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setVitals((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    if (!casePath) {
      alert("❌ No casePath defined.");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/api/vitals/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ casePath, vitals })
      });
      if (!res.ok) throw new Error("Submit error");
      alert("✅ Vitals submitted successfully.");
    } catch (err) {
      console.error(err);
      alert("❌ Failed to submit vitals.");
    }
  };

  if (!ready) {
    return <div className="p-4 text-yellow-600 italic">⏳ Waiting for patient/case context...</div>;
  }

  return (
    <div className="p-4 border rounded shadow bg-white text-black max-w-xl">
      <h2 className="text-xl font-semibold mb-4">Enter Vital Signs</h2>

      <div className="space-y-3">
        <input
          name="temperature"
          value={vitals.temperature}
          onChange={handleChange}
          placeholder="Temperature (°C)"
          className="w-full p-2 border rounded"
        />

        <input
          name="bp"
          value={vitals.bp}
          onChange={handleChange}
          placeholder="Blood Pressure (mmHg)"
          className="w-full p-2 border rounded"
        />

        <input
          name="heartRate"
          value={vitals.heartRate}
          onChange={handleChange}
          placeholder="Heart Rate (bpm)"
          className="w-full p-2 border rounded"
        />

        <input
          name="o2Sat"
          value={vitals.o2Sat}
          onChange={handleChange}
          placeholder="Oxygen Saturation (%)"
          className="w-full p-2 border rounded"
        />
      </div>

      <button
        onClick={handleSubmit}
        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
      >
        Submit Vitals
      </button>
    </div>
  );
}
