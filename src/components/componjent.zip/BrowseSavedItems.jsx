import React, { useState } from "react";

// Map type to backend endpoints
const endpoints = {
  lecture: {
    list: "http://localhost:5002/api/lexteacher/list_saved_lectures",
    get: "http://localhost:5002/api/lexteacher/get_saved_lecture",
    label: "Lectures"
  },
  quiz: {
    list: "http://localhost:5002/api/lexteacher/list_saved_quizzes",
    get: "http://localhost:5002/api/lexteacher/get_saved_quiz",
    label: "Quizzes"
  },
  simulation: {
    list: "http://localhost:5002/api/lexteacher/list_saved_simulations",
    get: "http://localhost:5002/api/lexteacher/get_saved_simulation",
    label: "Simulations"
  }
};

export default function BrowseSavedItems({ onLoadLecture, onLoadQuiz, onLoadSimulation }) {
  const [tab, setTab] = useState("lecture");
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchItems = async (itemType) => {
    setLoading(true);
    const res = await fetch(endpoints[itemType].list);
    const data = await res.json();
    setItems(data);
    setLoading(false);
  };

  React.useEffect(() => { fetchItems(tab); }, [tab]);

  const handleLoad = async (itemType, filename) => {
    const res = await fetch(`${endpoints[itemType].get}?filename=${encodeURIComponent(filename)}`);
    const data = await res.json();
    // ---- PATCHED ----
    console.log("DEBUG - loaded data:", data);
    if (itemType === "lecture" && data.lecture && onLoadLecture) onLoadLecture(data.lecture, data.topic || filename);
    else if (itemType === "quiz" && onLoadQuiz) onLoadQuiz(data, data.topic || filename); // <-- PATCH: always pass full data
    else if (itemType === "simulation" && data.simulation && onLoadSimulation) onLoadSimulation(data.simulation, data.topic || filename);
    else alert("Could not load.");
  };

  return (
    <div style={{
      background: "#f8f2ff", borderRadius: "1em", padding: "1.2em",
      margin: "2em 0 2.5em 0", border: "1px solid #e1d8f8"
    }}>
      <b>Browse Saved:</b>
      <div style={{ marginTop: "0.5em", marginBottom: "1em" }}>
        {["lecture", "quiz", "simulation"].map((type) => (
          <button key={type}
            onClick={() => setTab(type)}
            style={{
              marginRight: 10,
              fontWeight: tab === type ? "bold" : "normal",
              background: tab === type ? "#7c3aed" : "#e3ddff",
              color: tab === type ? "white" : "#371d75",
              border: "none",
              borderRadius: "0.5em",
              padding: "0.5em 1.2em",
              cursor: "pointer"
            }}>
            {endpoints[type].label}
          </button>
        ))}
      </div>
      {loading && <div>Loading...</div>}
      {!loading && items.length === 0 && <div>No saved {tab}s found.</div>}
      <div style={{ marginTop: "1em", maxHeight: 300, overflowY: "auto" }}>
        {items.map((l, i) => (
          <div key={l.filename} style={{
            borderBottom: "1px solid #ece6ff", padding: "0.7em 0",
            display: "flex", alignItems: "center", justifyContent: "space-between"
          }}>
            <div>
              <span style={{ fontWeight: "bold" }}>{l.topic || "Untitled"}</span>
              {" "} <span style={{ color: "#6330b6" }}>{l.difficulty}</span>
              <br />
              <span style={{ color: "#888", fontSize: "0.93em" }}>{l.timestamp}</span>
            </div>
            <button onClick={() => handleLoad(tab, l.filename)}
              style={{
                marginLeft: "1em", background: "#7c3aed", color: "white",
                border: "none", borderRadius: "0.5em", padding: "0.5em 1.2em", cursor: "pointer"
              }}>Open</button>
          </div>
        ))}
      </div>
    </div>
  );
}
