import React, { useState, useEffect } from "react";

const SYMPTOM_LIST = [
  "Fever",
  "Cough",
  "Fatigue",
  "Headache",
  "Diarrhea",
  "Shortness of breath",
  "Sore throat"
];

// API helpers
async function loadSymptomData() {
  const res = await fetch("/api/public/load", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "symptom" }),
  });
  const data = await res.json();
  return Array.isArray(data) ? data : [];
}

async function appendSymptomEntry(entry) {
  const res = await fetch("/api/public/append", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "symptom", entry }),
  });
  return await res.json();
}

async function clearSymptomData() {
  const res = await fetch("/api/public/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "symptom", data: [] }),
  });
  return await res.json();
}

// --- PATCH: Aggregation trigger ---
async function aggregateFromPatients() {
  const res = await fetch("/api/public/aggregate_patients", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
  });
  const data = await res.json();
  return data;
}

export default function PublicSymptomSurveillance() {
  const [entries, setEntries] = useState([]);
  const [current, setCurrent] = useState({ date: "", symptom: "", count: "" });
  const [loading, setLoading] = useState(true);
  const [aggMsg, setAggMsg] = useState(""); // PATCH: status message

  useEffect(() => {
    loadSymptomData().then((saved) => {
      setEntries(Array.isArray(saved) ? saved : []);
      setLoading(false);
    });
  }, []);

  const addEntry = async () => {
    if (!current.symptom || !current.count || !current.date) return;
    const entry = { ...current };
    setEntries([...entries, entry]);
    setCurrent({ date: "", symptom: "", count: "" });
    await appendSymptomEntry(entry);
  };

  const groupBySymptom = () => {
    const map = {};
    entries.forEach(({ symptom, count }) => {
      map[symptom] = (map[symptom] || 0) + parseInt(count);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]);
  };

  const clearAll = async () => {
    setEntries([]);
    await clearSymptomData();
  };

  // PATCH: trigger aggregation and reload data
  const handleAggregate = async () => {
    setAggMsg("Syncing with patients...");
    const data = await aggregateFromPatients();
    setAggMsg(data.status === "aggregated" ? `Aggregated ${data.added} symptom events from patients.` : (data.error || "Aggregation failed"));
    // Reload symptoms after aggregation
    setLoading(true);
    const saved = await loadSymptomData();
    setEntries(Array.isArray(saved) ? saved : []);
    setLoading(false);
    setTimeout(() => setAggMsg(""), 4000); // Hide message after 4s
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div>
        <h2 className="text-xl font-bold">🩺 Symptom Surveillance Engine</h2>

        {/* PATCH: Aggregation button */}
        <div className="mb-4">
          <button
            onClick={handleAggregate}
            className="bg-indigo-700 text-white px-4 py-2 rounded hover:bg-indigo-800 transition"
          >
            🔄 Sync With Patients
          </button>
          {aggMsg && <span className="ml-4 text-green-700 font-bold">{aggMsg}</span>}
        </div>

        <div className="grid grid-cols-3 gap-2">
          <select
            value={current.symptom}
            onChange={(e) => setCurrent({ ...current, symptom: e.target.value })}
            className="border px-2 py-1 rounded"
          >
            <option value="">Select Symptom</option>
            {SYMPTOM_LIST.map((symptom) => (
              <option key={symptom} value={symptom}>
                {symptom}
              </option>
            ))}
          </select>
          <input
            type="number"
            placeholder="Case Count"
            value={current.count}
            onChange={(e) => setCurrent({ ...current, count: e.target.value })}
            className="border px-2 py-1 rounded"
          />
          <input
            type="date"
            value={current.date}
            onChange={(e) => setCurrent({ ...current, date: e.target.value })}
            className="border px-2 py-1 rounded"
          />
        </div>

        <button onClick={addEntry} disabled={!current.symptom || !current.count || !current.date} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
          ➕ Log Symptom Case
        </button>

        <button onClick={clearAll} className="ml-3 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">
          🗑️ Clear All
        </button>

        <div className="mt-4">
          <h3 className="text-md font-semibold mb-2">📈 Summary by Symptom</h3>
          <ul className="text-sm list-disc ml-5">
            {groupBySymptom().map(([symptom, total], idx) => (
              <li key={idx}>
                {symptom}: {total} cases
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-4">
          <h3 className="text-md font-semibold mb-2">📝 All Logged Entries</h3>
          {loading ? (
            <div>Loading...</div>
          ) : (
            <ul className="text-sm list-decimal ml-5">
              {entries.map((entry, idx) => (
                <li key={idx}>
                  {entry.date}: {entry.symptom} - {entry.count} cases {entry.source === "clinical_auto" && <span className="text-indigo-600 ml-2">(auto)</span>}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
