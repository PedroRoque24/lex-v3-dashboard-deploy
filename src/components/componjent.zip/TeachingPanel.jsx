import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LectureOutputPanel from './LectureOutputPanel';
import QuizSelector from './QuizSelector';
import SimulationSelector from './SimulationSelector';
import BrowseSavedItems from "./BrowseSavedItems"; // PATCH: Unified browser for all types

function TeachingPanel() {
  const [inputTopic, setInputTopic] = useState('');
  const [lectureText, setLectureText] = useState('');
  const [quizData, setQuizData] = useState(null);
  const [simulationData, setSimulationData] = useState(null);
  const [mode, setMode] = useState('lecture');
  const [xpData, setXpData] = useState({ xp: 0, level: 1 });
  const [difficulty, setDifficulty] = useState('Moderate');

  useEffect(() => {
    const fetchXp = async () => {
      try {
        const res = await axios.get('/memory/xp_tracker.json');
        setXpData(res.data);
      } catch {
        console.error('Could not load XP data.');
      }
    };
    fetchXp();
  }, []);

  const cleanJsonString = (text) => {
    if (!text) return '';
    return text
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/```$/, '')
      .replace(/\n```$/, '')
      .replace(/[\r\n]+$/, '')
      .replace(/^\uFEFF/, '')
      .trim();
  };

  const tryParseJson = (text) => {
    try {
      return JSON.parse(text);
    } catch {
      try {
        const fixed = text.trim();
        const lastBrace = fixed.lastIndexOf('}');
        if (lastBrace !== -1) {
          return JSON.parse(fixed.substring(0, lastBrace + 1));
        }
      } catch {}
    }
    return null;
  };

  // === PATCHED ENDPOINTS BELOW ===

  const fetchLecture = async () => {
    if (!inputTopic.trim()) return;
    try {
      // PATCH: Save lectures via /api/lecture endpoint (saves to disk)
      const res = await axios.post('http://localhost:5002/api/lecture', {
        topic: inputTopic,
        difficulty
      });
      const raw = res.data.lecture || res.data;
      const clean = cleanJsonString(typeof raw === 'string' ? raw : JSON.stringify(raw));
      const parsed = tryParseJson(clean);
      if (parsed) {
        setLectureText(parsed);
        setMode('lecture');
      } else {
        console.error('Failed to parse lecture JSON.');
        setLectureText({ error: "Failed to parse JSON from server." });
      }
    } catch (error) {
      console.error('Error fetching lecture:', error);
      setLectureText({ error: "Network or server error." });
    }
  };

  const fetchQuiz = async () => {
    if (!inputTopic.trim()) return;
    try {
      // PATCH: Save quizzes via /api/quiz endpoint (saves to disk)
      const res = await axios.post('http://localhost:5002/api/quiz', {
        topic: inputTopic,
        difficulty
      });
      setQuizData(res.data.questions ? res.data : { questions: [] });
      setMode('quiz');
    } catch (error) {
      console.error('Error fetching quiz:', error);
    }
  };

  const fetchSimulation = async () => {
    if (!inputTopic.trim()) return;
    try {
      // Simulations were already correct!
      const res = await axios.post('http://localhost:5002/api/simulate', {
        topic: inputTopic,
        difficulty
      });
      let data = res.data;
      if (!data.case && data.hpi) {
        data = {
          case: {
            hpi: data.hpi,
            vitals: data.vitals,
            exam: data.exam,
            labs: data.labs,
            imaging: data.imaging,
            summary: data.summary || '',
          },
          decisions: data.decisions || []
        };
      }
      setSimulationData(data.case ? data : null);
      setMode('simulate');
    } catch (error) {
      console.error('Error fetching simulation:', error);
    }
  };

  // PATCH: Handler for loading saved lecture, quiz, or simulation
  const handleLoadSavedLecture = (lecture, topic) => {
    setLectureText(lecture);
    setMode('lecture');
    setInputTopic(topic || "");
  };

  const handleLoadSavedQuiz = (quiz, topic) => {
    setQuizData(quiz);
    setMode('quiz');
    setInputTopic(topic || "");
  };

  const handleLoadSavedSimulation = (simulation, topic) => {
    setSimulationData({ case: simulation });
    setMode('simulate');
    setInputTopic(topic || "");
  };

  return (
    <div style={{ padding: '1rem' }}>
      <h2>🎓 LexTeacher - Simulation & Teaching Mode</h2>

      {/* PATCH: Unified Browse for all types */}
      <BrowseSavedItems
        onLoadLecture={handleLoadSavedLecture}
        onLoadQuiz={handleLoadSavedQuiz}
        onLoadSimulation={handleLoadSavedSimulation}
      />

      <div style={{ margin: '1rem 0' }}>
        <label style={{ marginRight: '0.5rem', fontWeight: 'bold' }}>🧠 Select Difficulty:</label>
        <select value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
          <option value="Easy">Easy</option>
          <option value="Moderate">Moderate</option>
          <option value="Difficult">Difficult</option>
        </select>
      </div>
      <input
        value={inputTopic}
        onChange={(e) => setInputTopic(e.target.value)}
        placeholder="Enter medical topic..."
        style={{ padding: '0.5rem', width: '50%', marginRight: '1rem' }}
      />
      <button onClick={fetchLecture}>Get Lecture</button>
      <button onClick={fetchQuiz}>Get Quiz</button>
      <button onClick={fetchSimulation}>Simulate Patient</button>
      <div style={{ marginTop: '1rem' }}>
        <h4>📈 XP Tracker</h4>
        <p>Level: {xpData.level}</p>
        <p>XP: {xpData.xp}</p>
      </div>
      {mode === 'lecture' && lectureText?.error && (
        <div className="text-red-500">⚠️ {lectureText.error}</div>
      )}
      {mode === 'lecture' && lectureText && !lectureText.error && <LectureOutputPanel lectureText={lectureText} />}
      {mode === 'quiz' && quizData && <QuizSelector quizData={quizData} />}
      {mode === 'simulate' && simulationData && <SimulationSelector simulationData={simulationData} />}
    </div>
  );
}

export default TeachingPanel;
