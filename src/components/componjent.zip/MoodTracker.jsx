
import React, { useState } from "react";
import { useCaseContext } from "./CaseContext";

export default function MoodTracker() {
  const { casePath } = useCaseContext();
  const [mood, setMood] = useState("😐");
  const [status, setStatus] = useState("");

  const moodOptions = [
    { emoji: "😄", label: "Happy – feeling upbeat, positive" },
    { emoji: "😊", label: "Calm – relaxed or content" },
    { emoji: "😐", label: "Neutral – emotionally steady" },
    { emoji: "😞", label: "Sad – down or discouraged" },
    { emoji: "😡", label: "Angry – frustrated or upset" },
  ];

  const submitMood = async () => {
    try {
      const response = await fetch("http://127.0.0.1:5000/api/mood/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mood, case_path: casePath }),
      });
      const data = await response.json();
      if (data.status === "mood saved") {
        setStatus("✅ Mood logged.");
      } else {
        setStatus("⚠️ Error saving mood.");
      }
    } catch (err) {
      console.error("Mood submission error:", err);
      setStatus("❌ Submission failed.");
    }
  };

  return (
    <div style={{ padding: "1em", border: "1px solid #ddd", borderRadius: "8px" }}>
      <h3 className="text-xl font-semibold mb-2">Mood Tracker</h3>
      <div style={{ display: "flex", gap: "1em", fontSize: "1.5em", marginBottom: "0.5em" }}>
        {moodOptions.map((option) => (
          <span
            key={option.emoji}
            style={{
              cursor: "pointer",
              opacity: mood === option.emoji ? 1 : 0.5,
              transition: "opacity 0.2s",
            }}
            onClick={() => setMood(option.emoji)}
          >
            {option.emoji}
          </span>
        ))}
      </div>
      <div className="text-sm text-gray-400 mb-2">
        {moodOptions.find((m) => m.emoji === mood)?.label}
      </div>
      <button style={{ marginTop: "0.5em" }} onClick={submitMood}>
        Submit Mood
      </button>
      {status && <p className="mt-2 text-red-500">{status}</p>}
    </div>
  );
}
