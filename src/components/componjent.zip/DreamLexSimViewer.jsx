import React, { useEffect, useState } from "react";

export default function DreamLexSimViewer() {
  const [dreams, setDreams] = useState([]);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    fetch("/memory/scored-dreams.json")
      .then(res => res.json())
      .then(setDreams)
      .catch(() => setDreams([]));
  }, []);

  // PATCH: always show newest dreams first
  const orderedDreams = Array.isArray(dreams) ? dreams.slice().reverse() : [];
  const visibleDreams = expanded ? orderedDreams : orderedDreams.slice(0, 3);

  return (
    <div className="space-y-4">
      {Array.isArray(visibleDreams) && visibleDreams.map((d, i) => (
        <div key={i} className="bg-white text-black border rounded p-4 shadow">
          <h3 className="text-lg font-bold">{d?.origin ? d.origin.slice(0, 100) : "(no origin)"}</h3>
          <p className="text-sm italic mb-1">{d?.type || "(no type)"}</p>
          <p className="text-sm text-gray-600">{d?.timestamp || "(no timestamp)"}</p>
          {d?.content && <p className="mt-2">{d.content.slice(0, 200)}...</p>}
        </div>
      ))}
      {dreams.length > 3 && (
        <button
          className="text-blue-600 underline mt-2"
          onClick={() => setExpanded(!expanded)}
        >
          {expanded ? "Show Less" : `Show All (${dreams.length})`}
        </button>
      )}
      {(!dreams || dreams.length === 0) && (
        <p className="text-gray-500 italic">No dreams available.</p>
      )}
    </div>
  );
}
