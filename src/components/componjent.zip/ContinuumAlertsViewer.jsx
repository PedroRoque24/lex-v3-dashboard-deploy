
import React, { useState, useEffect } from 'react';
import { useCaseContext } from './CaseContext';

const ContinuumAlertsViewer = () => {
  const { casePath } = useCaseContext();
  const [alerts, setAlerts] = useState([]);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!casePath) return;
    fetch(`/memory/${casePath}/continuum_alerts.json`)
      .then(res => {
        if (!res.ok) throw new Error('Failed to fetch');
        return res.json();
      })
      .then(data => {
        if (!Array.isArray(data)) throw new Error('Invalid alert format');
        setAlerts(data);
      })
      .catch(err => {
        console.error('Continuum Alert Viewer error:', err);
        setAlerts([]);
      });
  }, [casePath]);

  const visibleAlerts = expanded ? alerts : alerts.slice(0, 5);

  return (
    <div style={{ padding: '1rem' }}>
      <h2 style={{ fontSize: '1.4rem', marginBottom: '0.75rem' }}>🧡 Continuum Alerts</h2>
      {visibleAlerts.length === 0 ? (
        <p>No alerts at this time.</p>
      ) : (
        <ul>
          {visibleAlerts.map((alert, idx) => (
            <li key={idx} style={{ marginBottom: '0.5rem' }}>
              <strong>[{(alert.level || 'UNKNOWN').toUpperCase()}]</strong>{' '}
              {alert.title || 'Untitled'} → {alert.message || 'No message'}
            </li>
          ))}
        </ul>
      )}
      {alerts.length > 5 && (
        <button
          onClick={() => setExpanded(!expanded)}
          style={{
            marginTop: '0.5rem',
            padding: '0.4rem 0.8rem',
            backgroundColor: '#eee',
            border: '1px solid #ccc',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          {expanded ? 'Show Less' : 'Show All Alerts'}
        </button>
      )}
    </div>
  );
};

export default ContinuumAlertsViewer;
