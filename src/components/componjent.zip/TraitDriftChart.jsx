
import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from "recharts";

const TraitDriftChart = () => {
  const [data, setData] = useState([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("/memory/trait_drift_timeline.json");
        const json = await res.json();
        const timeline = json.timeline || [];
        const parsed = timeline.map(entry => {
          const base = { time: entry.timestamp };
          entry.traits?.forEach(trait => {
            base[trait.name] = trait.drift;
          });
          return base;
        });
        setData(parsed);
      } catch (err) {
        console.error("Failed to load trait drift data:", err);
        setError(true);
      }
    };
    fetchData();
  }, []);

  const traitKeys = data.length > 0 ? Object.keys(data[0]).filter(k => k !== "time") : [];

  return (
    <div className="p-4 rounded-xl shadow bg-white">
      <h2 className="text-xl font-semibold mb-3">Symbolic Trait Drift Timeline</h2>
      {error && <p className="text-sm italic text-red-600">⚠️ Could not load trait drift timeline.</p>}
      {!error && data.length === 0 && <p className="text-sm italic text-gray-500">No trait drift data available.</p>}
      {!error && data.length > 0 && (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis domain={[-1, 1]} />
            <Tooltip />
            <Legend />
            {traitKeys.map((trait, index) => (
              <Line
                key={trait}
                type="monotone"
                dataKey={trait}
                stroke={`hsl(${index * 45}, 70%, 50%)`}
                strokeWidth={2}
                dot={false}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};

export default TraitDriftChart;
