import React, { useState, useEffect } from "react";

// Util functions for API
async function loadTrendData() {
  const res = await fetch("/api/public/load", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "trend" }),
  });
  const result = await res.json();
  return Array.isArray(result) ? result : [];
}

async function appendTrendEntry(entry) {
  const res = await fetch("/api/public/append", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "trend", entry }),
  });
  return await res.json();
}

async function clearTrendData() {
  const res = await fetch("/api/public/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "trend", data: [] }),
  });
  return await res.json();
}

export default function PublicTrendTracker() {
  const [data, setData] = useState([]);
  const [newEntry, setNewEntry] = useState({ disease: "", count: "", date: "" });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTrendData().then((saved) => {
      setData(Array.isArray(saved) ? saved : []);
      setLoading(false);
    });
  }, []);

  const addEntry = async () => {
    if (!newEntry.disease || !newEntry.count || !newEntry.date) return;
    const entry = { ...newEntry };
    setData([...data, entry]);
    setNewEntry({ disease: "", count: "", date: "" });
    await appendTrendEntry(entry);
  };

  const getSummary = () => {
    const grouped = {};
    data.forEach(({ disease, count }) => {
      if (!grouped[disease]) grouped[disease] = 0;
      grouped[disease] += parseInt(count);
    });
    return Object.entries(grouped);
  };

  const clearAll = async () => {
    setData([]);
    await clearTrendData();
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div>
        <h2 className="text-xl font-bold">📊 Epidemiological Trend Tracker</h2>

        <div className="grid grid-cols-3 gap-2">
          <input
            placeholder="Disease"
            value={newEntry.disease}
            onChange={(e) => setNewEntry({ ...newEntry, disease: e.target.value })}
            className="border px-2 py-1 rounded"
          />
          <input
            placeholder="Count"
            type="number"
            value={newEntry.count}
            onChange={(e) => setNewEntry({ ...newEntry, count: e.target.value })}
            className="border px-2 py-1 rounded"
          />
          <input
            type="date"
            value={newEntry.date}
            onChange={(e) => setNewEntry({ ...newEntry, date: e.target.value })}
            className="border px-2 py-1 rounded"
          />
        </div>

        <button onClick={addEntry} disabled={!newEntry.disease || !newEntry.count || !newEntry.date} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
          ➕ Add Entry
        </button>

        <button onClick={clearAll} className="ml-3 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition">
          🗑️ Clear All
        </button>

        <div className="mt-6">
          <h3 className="font-semibold text-md mb-2">Disease Totals</h3>
          <ul className="text-sm list-disc ml-5">
            {getSummary().map(([disease, count], idx) => (
              <li key={idx}>
                {disease}: {count} cases
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-6">
          <h3 className="font-semibold text-md mb-2">Raw Entries</h3>
          {loading ? (
            <div>Loading...</div>
          ) : (
            <ul className="text-sm list-decimal ml-5">
              {data.map((entry, idx) => (
                <li key={idx}>
                  {entry.date}: {entry.disease} - {entry.count} cases
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
