import React, { useState, useRef } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// Section keys & icons
const sections = [
  { key: 'introduction', icon: '🔍', label: 'Introduction' },
  { key: 'pathophysiology', icon: '🧬', label: 'Pathophysiology' },
  { key: 'signs_and_symptoms', icon: '😷', label: 'Signs and Symptoms' },
  { key: 'diagnosis', icon: '🧪', label: 'Diagnosis' },
  { key: 'treatment', icon: '💊', label: 'Treatment' },
  { key: 'common_mistakes', icon: '❌', label: 'Common Mistakes' },
  { key: 'visual_flowchart', icon: '🧭', label: 'Visual Flowchart', isFlowchart: true },
  { key: 'summary_table', icon: '📊', label: 'Summary Table', isTable: true },
];

// Helper for formatting bullets and tables
function formatBullets(text) {
  if (!text) return 'Not included.';
  return text
    .split(/\n+/)
    .filter(line => line.trim() !== '')
    .map((item) => `• ${item.replace(/^[-•]\s*/, '')}`)
    .join('\n');
}
function parseTableString(tableStr) {
  const rows = tableStr.split('\n').filter(r => r.includes('|'));
  const header = rows.length ? rows[0].split('|').map(c => c.trim()).filter(Boolean) : [];
  const body = rows.slice(2).map(r => r.split('|').map(c => c.trim()).filter(Boolean));
  return { header, body };
}

// BEAUTIFUL FLOWCHART PATCH!
function renderPrettyFlowchart(flowStr) {
  if (!flowStr) return null;
  const steps = flowStr.split("->").map(s => s.trim()).filter(Boolean);
  return (
    <div style={{
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: '1.1em',
      padding: '1.1em 0.5em 1.2em 0.5em',
      background: 'linear-gradient(90deg, #f7f7fc 0%, #e6eaff 100%)',
      borderRadius: '0.7em',
      overflowX: 'auto'
    }}>
      {steps.map((step, idx) => (
        <React.Fragment key={idx}>
          <div style={{
            display: 'inline-block',
            padding: '0.68em 1.25em',
            borderRadius: '1.6em',
            background: '#7c3aed',
            color: 'white',
            fontWeight: 600,
            fontSize: '1.08em',
            boxShadow: '0 2px 12px #7c3aed22'
          }}>
            {step}
          </div>
          {idx !== steps.length - 1 && (
            <span style={{
              fontSize: '2em',
              color: '#b3b6e1',
              margin: '0 0.3em',
              fontWeight: 800,
              userSelect: 'none'
            }}>⟶</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function Section({
  title,
  icon,
  content,
  isTable,
  isFlowchart,
  topic,
  onExpand,
  expanding,
  expanded,
  expandResult,
}) {
  let formatted = content || 'Not included.';
  if (typeof content === 'string' && (title.includes('Symptoms') || title.includes('Mistakes'))) {
    formatted = formatBullets(content);
  }

  return (
    <div style={{
      marginBottom: '2rem',
      padding: '1rem',
      background: '#f8f9fa',
      borderRadius: '0.75rem',
      boxShadow: '0 1px 4px rgba(0,0,0,0.06)'
    }}>
      <h2 style={{
        fontSize: '1.5rem',
        fontWeight: 'bold',
        display: 'flex',
        alignItems: 'center',
        color: '#212529'
      }}>
        <span style={{ marginRight: '0.5rem' }}>{icon}</span> {title}
      </h2>
      {isTable && content && content.includes('|') ? (
        (() => {
          const { header, body } = parseTableString(content);
          return (
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '1rem' }}>
              <thead>
                <tr>{header.map((h, i) => (
                  <th key={i} style={{ border: '1px solid #ccc', padding: '8px', background: '#e9ecef' }}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {body.map((row, r) => (
                  <tr key={r}>{row.map((cell, c) => (
                    <td key={c} style={{ border: '1px solid #ddd', padding: '8px' }}>{cell}</td>
                  ))}</tr>
                ))}
              </tbody>
            </table>
          );
        })()
      ) : isFlowchart && typeof content === 'string' ? (
        <div style={{ margin: '1.4em 0 1.2em 0' }}>
          {renderPrettyFlowchart(content)}
        </div>
      ) : (
        <pre style={{
          background: isFlowchart ? '#f0f0f0' : '#f9f9f9',
          padding: '1rem',
          whiteSpace: 'pre-wrap',
          borderRadius: '0.5rem',
          fontSize: '1rem',
          fontFamily: isTable || isFlowchart ? 'monospace' : 'Segoe UI, sans-serif',
          lineHeight: '1.7',
          overflowX: 'auto'
        }}>{formatted}</pre>
      )}

      {/* Expand/Explain Feature */}
      <div style={{ marginTop: '0.7rem' }}>
        <button
          onClick={onExpand}
          style={{
            background: '#7c3aed',
            color: 'white',
            padding: '0.45em 1.1em',
            borderRadius: '0.5em',
            border: 'none',
            fontWeight: 'bold',
            fontSize: '1.06em',
            cursor: 'pointer',
            marginRight: '1em'
          }}
          disabled={expanding}
        >
          {expanding ? 'Expanding...' : 'Expand / Explain'}
        </button>
        {expanded && (
          <div style={{
            marginTop: '1.1em',
            padding: '1em',
            background: '#f1eaff',
            borderRadius: '0.6em',
            boxShadow: '0 1px 4px rgba(80,60,160,0.11)'
          }}>
            {expanding ? (
              <div>
                <span role="img" aria-label="loading" style={{ fontSize: '2em' }}>🌀</span>
                <span style={{ marginLeft: '1em' }}>Generating detailed explanations...</span>
              </div>
            ) : (
              expandResult && (
                <div>
                  <div style={{ marginBottom: '0.7em', fontWeight: 500 }}>
                    <span role="img" aria-label="doctor" style={{ fontSize: '1.35em', marginRight: 8 }}>🧑‍⚕️</span>
                    <span style={{ color: '#553ccd', fontWeight: 'bold' }}>Doctor summary:</span>
                  </div>
                  <div style={{ marginBottom: '1.2em', color: '#34245c', fontSize: '1.03em', padding: '0.5em 1.1em', background: '#e9e7fd', borderRadius: '0.5em' }}>
                    {expandResult.doctor_detail || "No detail."}
                  </div>
                  <div style={{ marginBottom: '0.7em', fontWeight: 500 }}>
                    <span role="img" aria-label="trainee" style={{ fontSize: '1.35em', marginRight: 8 }}>🧑‍🎓</span>
                    <span style={{ color: '#22a2c6', fontWeight: 'bold' }}>Trainee summary:</span>
                  </div>
                  <div style={{ color: '#186f7d', fontSize: '1.03em', padding: '0.5em 1.1em', background: '#daf6fc', borderRadius: '0.5em' }}>
                    {expandResult.trainee_summary || "No summary."}
                  </div>
                </div>
              )
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function LectureOutputPanel({ lectureText }) {
  const panelRef = useRef(null);

  const [expandedSections, setExpandedSections] = useState({});
  const [expandingSections, setExpandingSections] = useState({});
  const [expandResults, setExpandResults] = useState({});
  const [question, setQuestion] = useState("");
  const [questionLoading, setQuestionLoading] = useState(false);
  const [questionAnswer, setQuestionAnswer] = useState(null);

  if (!lectureText) return null;

  let parsed;
  try {
    parsed = typeof lectureText === 'string' ? JSON.parse(lectureText) : lectureText;
  } catch {
    return <p>⚠️ Error parsing lecture content.</p>;
  }

  const topic = parsed?.topic || "Lecture";

  // Expand/explain handler
  const handleExpand = (sectionKey, sectionTitle, content) => async () => {
    if (expandingSections[sectionKey]) return; // already loading
    setExpandingSections((prev) => ({ ...prev, [sectionKey]: true }));
    setExpandedSections((prev) => ({ ...prev, [sectionKey]: true }));
    // POST to /api/lexteacher/explain with topic + section text
    try {
      const res = await fetch('http://localhost:5002/api/lexteacher/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, point_text: `${sectionTitle}: ${content}` }),
      });
      const data = await res.json();
      setExpandResults((prev) => ({ ...prev, [sectionKey]: data }));
    } catch (err) {
      setExpandResults((prev) => ({ ...prev, [sectionKey]: { doctor_detail: "Error loading.", trainee_summary: "" } }));
    }
    setExpandingSections((prev) => ({ ...prev, [sectionKey]: false }));
  };

  // Question submit
  const handleQuestionSubmit = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;
    setQuestionLoading(true);
    setQuestionAnswer(null);
    try {
      const res = await fetch('http://localhost:5002/api/lexteacher/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, lecture: parsed, question }),
      });
      const data = await res.json();
      setQuestionAnswer(data?.answer || "No answer.");
    } catch (err) {
      setQuestionAnswer("Error loading answer.");
    }
    setQuestionLoading(false);
  };

  // PDF Download Handler
  const handleDownloadPDF = async () => {
    const element = panelRef.current;
    const canvas = await html2canvas(element, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: [canvas.width, canvas.height]
    });
    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
    pdf.save(`${topic.replace(/\s+/g, '_')}_lecture_${new Date().toISOString().slice(0,10)}.pdf`);
  };

  return (
    <div>
      <div style={{ textAlign: 'right', marginBottom: '1em' }}>
        <button
          onClick={handleDownloadPDF}
          style={{
            background: '#7c3aed', color: 'white', padding: '0.6em 1.3em', borderRadius: '7px',
            border: 'none', fontWeight: 'bold', fontSize: '1.07em', cursor: 'pointer'
          }}
        >
          Download as PDF
        </button>
      </div>
      <div ref={panelRef} style={{
        padding: '2rem',
        maxWidth: '900px',
        margin: '0 auto',
        fontFamily: 'Segoe UI, Roboto, sans-serif',
        color: '#222',
        background: '#fff'
      }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#0a58ca', marginBottom: '2rem' }}>
          📚 Lecture Output
        </h1>
        {sections.map(({ key, icon, label, isTable, isFlowchart }) => (
          <Section
            key={key}
            title={label}
            icon={icon}
            content={parsed[key]}
            isTable={isTable}
            isFlowchart={isFlowchart}
            topic={topic}
            onExpand={handleExpand(key, label, parsed[key])}
            expanding={!!expandingSections[key]}
            expanded={!!expandedSections[key]}
            expandResult={expandResults[key]}
          />
        ))}
        {/* ASK LEXTEACHER box */}
        <div style={{
          marginTop: '2.5em',
          background: '#f7f5ff',
          padding: '1.5em 2em',
          borderRadius: '0.9em',
          boxShadow: '0 1px 8px rgba(123,87,237,0.12)'
        }}>
          <h3 style={{ fontWeight: 'bold', fontSize: '1.2em', color: '#6741d9', marginBottom: '0.7em' }}>
            <span role="img" aria-label="student">🧑‍🎓</span> Ask LexTeacher about this lecture:
          </h3>
          <form onSubmit={handleQuestionSubmit} style={{ display: 'flex', alignItems: 'center', gap: '0.7em' }}>
            <input
              type="text"
              value={question}
              onChange={e => setQuestion(e.target.value)}
              placeholder="Type your question (e.g. 'What are the risks of treatment?')"
              style={{
                flex: 1,
                padding: '0.8em',
                borderRadius: '0.5em',
                border: '1px solid #b7aaff',
                fontSize: '1.1em'
              }}
              disabled={questionLoading}
            />
            <button
              type="submit"
              style={{
                background: '#7c3aed',
                color: 'white',
                padding: '0.75em 1.5em',
                borderRadius: '0.5em',
                border: 'none',
                fontWeight: 'bold',
                fontSize: '1.09em',
                cursor: 'pointer'
              }}
              disabled={questionLoading}
            >
              {questionLoading ? (
                <span><span role="img" aria-label="hourglass">⏳</span> Asking...</span>
              ) : "Ask"}
            </button>
          </form>
          {questionLoading && (
            <div style={{ marginTop: '1em', color: '#553ccd', fontWeight: 500 }}>
              <span role="img" aria-label="loading">🌀</span> Getting answer...
            </div>
          )}
          {questionAnswer && (
            <div style={{
              marginTop: '1.5em',
              background: '#e7f2fe',
              padding: '1em',
              borderRadius: '0.6em',
              color: '#115',
              fontWeight: 500,
              fontSize: '1.07em'
            }}>
              <span style={{ marginRight: '0.6em', fontSize: '1.15em' }}>🧑‍🏫</span>
              {questionAnswer}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default LectureOutputPanel;

