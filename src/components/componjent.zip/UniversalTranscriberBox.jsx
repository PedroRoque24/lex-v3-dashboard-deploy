import React, { useState } from "react";

export default function UniversalTranscriberBox() {
  const [recording, setRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [editMode, setEditMode] = useState(false);

  // Placeholder: polling logic for transcript file, to be replaced by API or socket later
  // In future, replace fetch with: fetch("/api/shadowbrain/transcribe/latest")
  const fetchTranscript = async () => {
    // Dummy: Replace with actual fetch or file-watching logic
    const resp = await fetch("/shadow_memory/transcript_latest.txt");
    const text = await resp.text();
    setTranscript(text);
  };

  const handleStart = () => {
    setRecording(true);
    // In future: fetch("/api/shadowbrain/transcribe/start", { method: "POST" })
    // For now: Just fake UI toggle, and maybe poll for transcript
    // You could setInterval(fetchTranscript, 5000) if you want auto-poll
  };

  const handleStop = () => {
    setRecording(false);
    // In future: fetch("/api/shadowbrain/transcribe/stop", { method: "POST" })
    fetchTranscript(); // get final transcript after stop
  };

  const downloadTranscript = () => {
    const blob = new Blob([transcript], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "Universal_Transcript.txt";
    a.click();
  };

  return (
    <div style={{
      marginTop: "2em",
      background: "#f4f0ff",
      padding: "1.5em",
      borderRadius: "10px",
      border: "2px solid #7c3aed"
    }}>
      <h3 style={{ color: "#7c3aed", marginBottom: "0.7em" }}>
        🧠 Universal (ShadowBrain) Transcriber
      </h3>
      <button onClick={recording ? handleStop : handleStart} style={{
        background: recording ? "#c026d3" : "#7c3aed",
        color: "#fff",
        padding: "0.6em 1.3em",
        border: "none",
        borderRadius: "6px",
        fontWeight: "bold"
      }}>
        {recording ? "⏹ Stop Universal Transcriber" : "🎙 Start Universal Transcriber"}
      </button>
      <button onClick={fetchTranscript} style={{
        marginLeft: "1em",
        padding: "0.6em 1.3em",
        borderRadius: "6px"
      }}>
        🔄 Refresh Transcript
      </button>

      {transcript && (
        <div style={{ marginTop: "1.5em" }}>
          <h4>📄 Universal Transcript:</h4>
          <div>
            <button onClick={() => setEditMode(!editMode)} style={{
              marginBottom: "0.7em",
              background: "#ede9fe",
              color: "#6d28d9",
              border: "none",
              borderRadius: "5px",
              padding: "0.3em 1em",
              fontWeight: "bold"
            }}>
              {editMode ? "✅ Save & Lock" : "✏️ Edit Transcript"}
            </button>
            <button onClick={downloadTranscript} style={{
              marginLeft: "0.7em",
              background: "#a78bfa",
              color: "#fff",
              border: "none",
              borderRadius: "5px",
              padding: "0.3em 1em"
            }}>
              📥 Download TXT
            </button>
          </div>
          {editMode ? (
            <textarea
              value={transcript}
              onChange={e => setTranscript(e.target.value)}
              rows={12}
              style={{ width: "100%", padding: "1em", borderRadius: "7px", border: "1px solid #ccc" }}
            />
          ) : (
            <div style={{
              whiteSpace: "pre-wrap",
              backgroundColor: "#fff",
              padding: "1em",
              border: "1px solid #d1d5db",
              borderRadius: "7px"
            }}>
              {transcript}
            </div>
          )}
        </div>
      )}

      {!transcript && (
        <div style={{ marginTop: "1em", color: "#888" }}>
          <em>No transcript available yet. Start transcriber and refresh when ready.</em>
        </div>
      )}
    </div>
  );
}
