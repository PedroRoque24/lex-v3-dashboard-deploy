import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext.jsx";

const EmotionalSummaryViewer = () => {
  const { casePath } = useCaseContext();
  const [summary, setSummary] = useState(null);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!casePath) return;
    fetch(`/memory/${casePath}/emotional_summary.json`)
      .then((res) => res.json())
      .then((data) => setSummary(data))
      .catch(() => setSummary(null));
  }, [casePath]);

  return (
    <div className="p-4 bg-white text-black rounded shadow-md mt-4">
      <h2 className="text-xl font-bold mb-2">📊 Emotional Summary</h2>
      {!summary ? (
        <p className="text-sm italic text-gray-500">No summary available.</p>
      ) : (
        <div className="space-y-2 text-sm">
          <p className="text-gray-600">🕒 <strong>{new Date(summary.timestamp).toLocaleString()}</strong></p>
          <p>Entries analyzed: <strong>{summary.entries_analyzed}</strong></p>
          {expanded && (
            <>
              <div>
                <p className="font-semibold mt-2">Top GPT Emotions:</p>
                <ul className="list-disc ml-5">
                  {summary.top_gpt_emotions.map((e, i) => (
                    <li key={i}>{e[0]} ({e[1]})</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="font-semibold mt-2">Top Local Emotions:</p>
                <ul className="list-disc ml-5">
                  {summary.top_local_emotions.map((e, i) => (
                    <li key={i}>{e[0]} ({e[1]})</li>
                  ))}
                </ul>
              </div>
              <div className="bg-gray-100 border p-3 rounded mt-3 text-sm italic">
                {summary.summary_text}
              </div>
            </>
          )}
          <button
            onClick={() => setExpanded(!expanded)}
            className="text-sm text-blue-600 mt-2 hover:underline"
          >
            {expanded ? "Show Less" : "Show More"}
          </button>
        </div>
      )}
    </div>
  );
};

export default EmotionalSummaryViewer;