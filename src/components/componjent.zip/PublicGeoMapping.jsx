import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const DEFAULT_COORDS = [38.7169, -9.1399]; // Lisbon, Portugal

// API helpers
async function loadGeoPoints() {
  const res = await fetch("/api/public/load", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "geo" }),
  });
  const data = await res.json();
  return Array.isArray(data) ? data : [];
}

async function appendGeoPoint(point) {
  const res = await fetch("/api/public/append", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "geo", entry: point }),
  });
  return await res.json();
}

async function clearGeoPoints() {
  const res = await fetch("/api/public/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "geo", data: [] }),
  });
  return await res.json();
}

export default function PublicGeoMapping() {
  const [points, setPoints] = useState([]);
  const [newPoint, setNewPoint] = useState({ disease: "", lat: "", lng: "" });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadGeoPoints().then((saved) => {
      setPoints(Array.isArray(saved) ? saved : []);
      setLoading(false);
    });
  }, []);

  const addPoint = async () => {
    if (!newPoint.disease || !newPoint.lat || !newPoint.lng) return;
    const entry = { ...newPoint };
    setPoints([...points, entry]);
    setNewPoint({ disease: "", lat: "", lng: "" });
    await appendGeoPoint(entry);
  };

  const clearAll = async () => {
    setPoints([]);
    await clearGeoPoints();
  };

  return (
    <div className="mt-4 space-y-4">
      <h2 className="text-xl font-bold">🗺️ Geo-Mapping of Reported Cases</h2>

      <div className="grid grid-cols-3 gap-2">
        <input
          placeholder="Disease"
          value={newPoint.disease}
          onChange={(e) => setNewPoint({ ...newPoint, disease: e.target.value })}
          className="border px-2 py-1 rounded"
        />
        <input
          placeholder="Latitude"
          value={newPoint.lat}
          onChange={(e) => setNewPoint({ ...newPoint, lat: e.target.value })}
          className="border px-2 py-1 rounded"
        />
        <input
          placeholder="Longitude"
          value={newPoint.lng}
          onChange={(e) => setNewPoint({ ...newPoint, lng: e.target.value })}
          className="border px-2 py-1 rounded"
        />
      </div>

      <button
        className="bg-blue-600 text-white px-4 py-2 rounded"
        onClick={addPoint}
      >
        ➕ Add Case to Map
      </button>

      <button
        className="ml-3 bg-red-500 text-white px-4 py-2 rounded"
        onClick={clearAll}
      >
        🗑️ Clear All
      </button>

      <MapContainer
        center={DEFAULT_COORDS}
        zoom={6}
        style={{ height: "500px", width: "100%" }}
        className="rounded border shadow mt-6"
      >
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {!loading &&
          points.map((p, idx) => (
            <Marker key={idx} position={[parseFloat(p.lat), parseFloat(p.lng)]}>
              <Popup>
                <strong>{p.disease}</strong>
                <br />
                Lat: {p.lat}, Lng: {p.lng}
              </Popup>
            </Marker>
          ))}
      </MapContainer>
    </div>
  );
}
