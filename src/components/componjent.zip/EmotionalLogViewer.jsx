
import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext";

const EmotionalLogViewer = () => {
  const { casePath } = useCaseContext();
  const [log, setLog] = useState([]);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!casePath) return;
    fetch(`/memory/${casePath}/emotional_log.json`)
      .then(res => res.json())
      .then(data => setLog(data.reverse()))
      .catch(() => setLog([]));
  }, [casePath]);

  const displayed = expanded ? log : log.slice(0, 3);

  return (
    <div className="p-4 bg-white text-black rounded shadow-md mt-4">
      <h2 className="text-xl font-bold mb-3">🧠 Emotional Reflection Log</h2>
      {log.length === 0 ? (
        <p className="text-sm italic text-gray-600">No journal reflections analyzed yet.</p>
      ) : (
        <>
          <ul className="space-y-4">
            {displayed.map((entry, i) => (
              <li key={i} className="border p-3 rounded bg-gray-50">
                <p className="text-sm text-gray-600">
                  🕒 <strong>{new Date(entry.timestamp).toLocaleString()}</strong>
                </p>
                <p className="text-sm italic mb-2">"{entry.input}"</p>
                {entry.emotional_signals ? (
                  <ul className="text-sm list-disc ml-5">
                    {entry.emotional_signals.map((e, j) => (
                      <li key={j}>
                        <strong>{e.emotion}</strong> <span className="text-xs text-gray-500">({e.source}, {e.priority})</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <>
                    {entry.gpt_emotion && (
                      <p className="text-purple-700 text-sm mb-1">
                        GPT Emotion: <strong>{entry.gpt_emotion}</strong>
                      </p>
                    )}
                    {Array.isArray(entry.local_tags) && entry.local_tags.length > 0 && (
                      <ul className="text-sm list-disc ml-5">
                        {entry.local_tags.map((tag, j) => (
                          <li key={j}>{tag}</li>
                        ))}
                      </ul>
                    )}
                  </>
                )}
              </li>
            ))}
          </ul>
          {log.length > 3 && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="mt-2 text-sm text-blue-600 hover:underline"
            >
              {expanded ? "Show Less" : "Show More"}
            </button>
          )}
        </>
      )}
    </div>
  );
};

export default EmotionalLogViewer;
