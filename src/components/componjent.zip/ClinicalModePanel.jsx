import React, { useState, useEffect } from 'react';
import TranscribeAndAutofillButton from './TranscribeAndAutofillButton';
import UniversalTranscriberBox from './UniversalTranscriberBox';

export default function ClinicalModePanel() {
  // Simple state for open/closed accordions
  const [openSection, setOpenSection] = useState('anamnesis');

  // Helper to toggle a section
  const toggle = (section) => setOpenSection(openSection === section ? null : section);

  return (
    <div className="clinical-mode-panel p-4">
      <h2 className="text-2xl font-black mb-6 text-lex-accent drop-shadow">Clinical Mode</h2>

      {/* Accordion: Anamnesis */}
      <div className="mb-3">
        <button
          className={`w-full text-left py-3 px-4 rounded-2xl font-bold text-lg bg-lex-card border border-lex-accent shadow-lex flex justify-between items-center transition-all ${
            openSection === 'anamnesis' ? 'bg-lex-accent/20 text-lex-accent' : 'text-white'
          }`}
          onClick={() => toggle('anamnesis')}
        >
          Anamnesis
          <span className="ml-2">{openSection === 'anamnesis' ? '▲' : '▼'}</span>
        </button>
        {openSection === 'anamnesis' && (
          <div className="bg-lex-card/80 p-4 rounded-b-2xl mt-1 shadow-inner">
            <label className="block font-semibold">Anamnesis</label>
            <textarea id="anamnesis-input" className="w-full border border-lex-accent bg-black text-white p-2 rounded-xl my-2" rows="4"></textarea>
          </div>
        )}
      </div>

      {/* Accordion: Chronic Medications */}
      <div className="mb-3">
        <button
          className={`w-full text-left py-3 px-4 rounded-2xl font-bold text-lg bg-lex-card border border-lex-accent shadow-lex flex justify-between items-center transition-all ${
            openSection === 'chronic' ? 'bg-lex-accent/20 text-lex-accent' : 'text-white'
          }`}
          onClick={() => toggle('chronic')}
        >
          Chronic Medications
          <span className="ml-2">{openSection === 'chronic' ? '▲' : '▼'}</span>
        </button>
        {openSection === 'chronic' && (
          <div className="bg-lex-card/80 p-4 rounded-b-2xl mt-1 shadow-inner">
            <label className="block font-semibold">Chronic Medications</label>
            <input id="chronic-meds" className="w-full border border-lex-accent bg-black text-white p-2 rounded-xl my-2" />
          </div>
        )}
      </div>

      {/* Accordion: Drug Allergies */}
      <div className="mb-3">
        <button
          className={`w-full text-left py-3 px-4 rounded-2xl font-bold text-lg bg-lex-card border border-lex-accent shadow-lex flex justify-between items-center transition-all ${
            openSection === 'allergies' ? 'bg-lex-accent/20 text-lex-accent' : 'text-white'
          }`}
          onClick={() => toggle('allergies')}
        >
          Drug Allergies
          <span className="ml-2">{openSection === 'allergies' ? '▲' : '▼'}</span>
        </button>
        {openSection === 'allergies' && (
          <div className="bg-lex-card/80 p-4 rounded-b-2xl mt-1 shadow-inner">
            <label className="block font-semibold">Drug Allergies</label>
            <input id="allergy-input" className="w-full border border-lex-accent bg-black text-white p-2 rounded-xl my-2" />
          </div>
        )}
      </div>

      {/* Accordion: Family History */}
      <div className="mb-3">
        <button
          className={`w-full text-left py-3 px-4 rounded-2xl font-bold text-lg bg-lex-card border border-lex-accent shadow-lex flex justify-between items-center transition-all ${
            openSection === 'family' ? 'bg-lex-accent/20 text-lex-accent' : 'text-white'
          }`}
          onClick={() => toggle('family')}
        >
          Family History
          <span className="ml-2">{openSection === 'family' ? '▲' : '▼'}</span>
        </button>
        {openSection === 'family' && (
          <div className="bg-lex-card/80 p-4 rounded-b-2xl mt-1 shadow-inner">
            <label className="block font-semibold">Family History</label>
            <input id="family-history-input" className="w-full border border-lex-accent bg-black text-white p-2 rounded-xl my-2" />
          </div>
        )}
      </div>

      {/* Accordion: Substance Use */}
      <div className="mb-3">
        <button
          className={`w-full text-left py-3 px-4 rounded-2xl font-bold text-lg bg-lex-card border border-lex-accent shadow-lex flex justify-between items-center transition-all ${
            openSection === 'substance' ? 'bg-lex-accent/20 text-lex-accent' : 'text-white'
          }`}
          onClick={() => toggle('substance')}
        >
          Substance Use
          <span className="ml-2">{openSection === 'substance' ? '▲' : '▼'}</span>
        </button>
        {openSection === 'substance' && (
          <div className="bg-lex-card/80 p-4 rounded-b-2xl mt-1 shadow-inner">
            <label className="block font-semibold">Substance Use</label>
            <input id="substance-use-input" className="w-full border border-lex-accent bg-black text-white p-2 rounded-xl my-2" />
          </div>
        )}
      </div>

      {/* Transcription and ShadowBrain sections (always visible) */}
      <div className="my-5">
        <TranscribeAndAutofillButton />
        <UniversalTranscriberBox />
      </div>

      {/* ...add more collapsible sections as you expand Clinical Mode! */}
    </div>
  );
}

