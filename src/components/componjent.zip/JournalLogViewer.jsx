import React, { useEffect, useState } from "react";
import { useCaseContext } from './CaseContext.jsx';

const JournalLogViewer = () => {
  const { casePath } = useCaseContext();
  const [entries, setEntries] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!casePath) return;

    fetch("http://localhost:5000/api/journal/get", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath })
    })
      .then((res) => res.json())
      .then((data) => setEntries(data || []))
      .catch((err) => {
        console.error("❌ Journal fetch error:", err);
        setError("❌ Could not load journal entries.");
      });
  }, [casePath]);

  return (
    <div className="mt-4 bg-white p-4 rounded shadow text-sm text-black">
      <h3 className="text-lg font-bold mb-2">📚 Journal Log</h3>
      {error && <p className="text-red-600">{error}</p>}
      {casePath === null && entries.length === 0 && (
        <p className="text-yellow-600">⚠️ No case selected.</p>
      )}
      {!error && entries.length === 0 && casePath && (
        <p className="italic text-gray-500">No journal entries found for this case.</p>
      )}
      <ul className="space-y-2">
        {entries.map((entry, i) => (
          <li key={i} className="border-l-4 border-blue-400 pl-3">
            <p className="text-xs text-gray-600 mb-1">
              🗓️ {new Date(entry.timestamp).toLocaleString()}
            </p>
            <p className="text-sm text-black">{entry.content}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default JournalLogViewer;