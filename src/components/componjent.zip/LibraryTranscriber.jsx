import React, { useState, useRef } from "react";
import axios from "axios";

export default function LibraryTranscriber() {
  const [recording, setRecording] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [editMode, setEditMode] = useState(false);
  const recorderRef = useRef(null);
  const chunksRef = useRef([]);

  const toggleRecording = async () => {
    if (!recording) {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      recorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        if (blob.size < 300) {
          alert("Recording too short.");
          return;
        }

        const formData = new FormData();
        formData.append("audio", blob, "recording.webm");

        try {
          // This expects your backend to return { transcript: "..." }
          const resp = await axios.post("/api/clinical/transcribe_and_fill", formData);
          const { transcript } = resp.data;
          setTranscript(transcript);
        } catch (err) {
          console.error("Transcription failed:", err);
          alert("Transcription failed.");
        }
      };

      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
    } else {
      recorderRef.current?.stop();
      setRecording(false);
    }
  };

  const downloadTranscript = () => {
    const blob = new Blob([transcript], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "LibraryTranscript.txt";
    a.click();
  };

  return (
    <div style={{ marginTop: "2em", background: "#f8f8f8", padding: "1em", borderRadius: "8px" }}>
      <h3>🎤 Transcription (Library Mode)</h3>
      <button
        className={recording ? "bg-red-500 text-white px-4 py-2 rounded" : "bg-blue-500 text-white px-4 py-2 rounded"}
        onClick={toggleRecording}
      >
        {recording ? "Stop Recording" : "Start Transcription"}
      </button>

      {transcript && (
        <div style={{ marginTop: "1em" }}>
          <h4>📝 Transcript:</h4>
          <div style={{ marginBottom: "0.5em" }}>
            <button onClick={() => setEditMode(!editMode)}>
              {editMode ? "✅ Save & Lock" : "✏️ Edit Transcript"}
            </button>
          </div>
          {editMode ? (
            <textarea
              rows="10"
              className="w-full p-2 border rounded"
              value={transcript}
              onChange={(e) => setTranscript(e.target.value)}
            />
          ) : (
            <div style={{ whiteSpace: "pre-wrap", backgroundColor: "#fff", padding: "1em", border: "1px solid #ccc" }}>
              {transcript}
            </div>
          )}
          <div style={{ marginTop: "1em" }}>
            <button
              className="bg-blue-600 text-white px-3 py-1 rounded"
              onClick={downloadTranscript}
            >
              📥 Download Transcript
            </button>
            <button
              className="ml-2 bg-green-600 text-white px-3 py-1 rounded"
              onClick={() => navigator.clipboard.writeText(transcript)}
              style={{ marginLeft: "10px" }}
            >
              📋 Copy Transcript
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
