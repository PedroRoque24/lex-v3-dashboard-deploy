import React, { useState, useEffect } from "react";
import axios from "axios";
import { useCaseContext } from "./CaseContext";

export default function LibraryCertificateArchive() {
  const { casePath } = useCaseContext() || {};
  const [savedReports, setSavedReports] = useState([]);
  const [selected, setSelected] = useState(null);

  // Load certificates for this case
  useEffect(() => {
    if (!casePath) return;
    axios.post("http://localhost:5000/api/certificates/get", { case_path: casePath })
      .then(res => setSavedReports(res.data || []));
  }, [casePath]);

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file || !casePath) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const content = event.target.result;
      // Save to backend
      await axios.post("http://localhost:5000/api/certificates/add", {
        case_path: casePath,
        name: file.name,
        content,
      });
      // Reload list
      const res = await axios.post("http://localhost:5000/api/certificates/get", { case_path: casePath });
      setSavedReports(res.data || []);
    };
    reader.readAsText(file);
  };

  const handleAttach = async () => {
    if (!selected || !casePath) return;
    await axios.post("http://localhost:5000/api/certificates/attach", {
      case_path: casePath,
      name: selected.name,
      content: selected.content,
    });
    alert("Certificate attached to patient case.");
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div>
        <h2 className="text-xl font-bold">Certificate Archive</h2>
        <input type="file" accept=".txt" onChange={handleImport} />

        <ul className="space-y-2 mt-2">
          {savedReports.map((r, idx) => (
            <li key={idx}>
              <button
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                onClick={() => setSelected(r)}
                type="button"
              >
                📄 {r.name}
              </button>
            </li>
          ))}
        </ul>

        {selected && (
          <div className="mt-4">
            <h3 className="font-semibold mb-2">Preview: {selected.name}</h3>
            <textarea
              rows={12}
              className="w-full border rounded p-2 text-sm"
              value={selected.content}
              readOnly
            />
            <button
              className="mt-2 bg-green-600 text-white px-4 py-2 rounded"
              onClick={handleAttach}
              type="button"
            >
              📎 Attach to Patient Case
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
