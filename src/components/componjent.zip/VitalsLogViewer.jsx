import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext";

export default function VitalsLogViewer() {
  const { casePath } = useCaseContext();
  const [vitalsLog, setVitalsLog] = useState([]);

  useEffect(() => {
    if (!casePath) return;

    fetch("http://localhost:5000/api/vitals/get", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath })
    })
      .then(res => res.json())
      .then(setVitalsLog)
      .catch(err => {
        console.error("Vitals log fetch error:", err);
        setVitalsLog([]);
      });
  }, [casePath]);

  const fallback = (val) => val && val.trim() !== "" ? val : "—";

  if (!casePath) {
    return <div className="p-4 text-red-600">⚠️ No patient/case selected.</div>;
  }

  if (vitalsLog.length === 0) {
    return <div className="p-4 text-gray-500 italic">No vitals submitted yet.</div>;
  }

  return (
    <div className="p-4 bg-white text-black rounded shadow max-w-3xl mt-4">
      <h2 className="text-xl font-semibold mb-3">📋 Vitals History</h2>
      <div className="space-y-3">
        {vitalsLog.map((v, i) => (
          <div key={i} className="border rounded p-3 bg-gray-50 shadow-sm">
            <div className="text-xs text-gray-600 mb-1">
              <strong>🕒 {new Date(v.timestamp).toLocaleString()}</strong>
            </div>
            <div className="grid grid-cols-4 gap-4 text-sm font-mono">
              <div>🌡 Temp: {fallback(v.temperature)} °C</div>
              <div>💉 BP: {fallback(v.bp)}</div>
              <div>❤️ HR: {fallback(v.heartRate)} bpm</div>
              <div>🫁 O₂ Sat: {fallback(v.o2Sat)}%</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
