import React, { useState, useRef } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// Helper: Recursively search for decisions array
function findDecisions(obj) {
  if (!obj || typeof obj !== "object") return [];
  if (Array.isArray(obj.decisions)) return obj.decisions;
  for (const key of Object.keys(obj)) {
    if (key.toLowerCase().includes("decision") && Array.isArray(obj[key]))
      return obj[key];
    if (typeof obj[key] === "object") {
      const found = findDecisions(obj[key]);
      if (found.length) return found;
    }
  }
  return [];
}

// Helper: Find the simulation case object (HPI, labs, etc)
function findCase(obj) {
  if (!obj || typeof obj !== "object") return {};
  if (obj.simulation && typeof obj.simulation === "object") return obj.simulation;
  if (obj.case && typeof obj.case === "object") return obj.case;
  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === "object") {
      const found = findCase(obj[key]);
      if (Object.keys(found).length) return found;
    }
  }
  // fallback: maybe the object itself is a simulation case
  if (obj.hpi || obj.exam || obj.labs || obj.summary) return obj;
  return {};
}

// For pretty labs display
function renderNestedLab(obj, indent = 0) {
  if (!obj || typeof obj !== 'object') return String(obj);
  return Object.entries(obj).map(([k, v]) => {
    if (typeof v === 'object') {
      return (
        <div key={k} style={{ marginTop: '0.5rem', fontWeight: 'bold' }}>
          {k.toUpperCase()}:
          <div style={{ marginLeft: '1rem', fontWeight: 'normal' }}>
            {renderNestedLab(v, indent + 12)}
          </div>
        </div>
      );
    }
    return (
      <div key={k} style={{ marginLeft: '1rem', paddingBottom: '0.25rem' }}>
        {k}: <span style={{ fontWeight: 500 }}>{v}</span>
      </div>
    );
  });
}

function SimulationSelector({ simulationData }) {
  const panelRef = useRef(null);

  // NEW: Use universal loaders
  const caseData = findCase(simulationData);
  const decisions = findDecisions(simulationData);

  const [responses, setResponses] = useState({});
  const [showFeedback, setShowFeedback] = useState({});
  const [showAnswer, setShowAnswer] = useState({});
  const [completed, setCompleted] = useState(false);

  const handleChoice = (questionPrompt, choice) => {
    setResponses(prev => ({ ...prev, [questionPrompt]: choice }));
    setShowFeedback(prev => ({ ...prev, [questionPrompt]: true }));
  };

  const submitSimulation = () => {
    setCompleted(true);
  };

  const safeExplanation = (q) => {
    if (!q) return "Explanation not provided.";
    if (typeof q.explanation === 'string' && q.explanation.trim() !== '') {
      return q.explanation;
    }
    return "Explanation not provided.";
  };

  const safeSummary = (data) => {
    const sum = data?.summary;
    return typeof sum === 'string' && sum.trim() !== '' ? sum : "Summary not provided.";
  };

  // PDF Download Handler (now includes decisions)
  const handleDownloadPDF = async () => {
    const element = panelRef.current;
    const canvas = await html2canvas(element, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: [canvas.width, canvas.height]
    });
    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
    pdf.save(
      `simulation_${caseData.topic ? caseData.topic.replace(/\s+/g, "_") : "case"}_${new Date().toISOString().slice(0, 10)}.pdf`
    );
  };

  return (
    <div>
      <div style={{ textAlign: 'right', marginBottom: '1em' }}>
        <button
          onClick={handleDownloadPDF}
          style={{
            background: '#7c3aed', color: 'white', padding: '0.6em 1.3em', borderRadius: '7px',
            border: 'none', fontWeight: 'bold', fontSize: '1.07em', cursor: 'pointer'
          }}
        >
          Download as PDF
        </button>
      </div>
      <div ref={panelRef} style={{ padding: '1rem', maxWidth: '800px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>🧠 Simulated Patient Case</h2>
        <div style={{ marginBottom: '1rem' }}>
          <h3>📋 HPI:</h3>
          <p>{caseData.hpi || "No HPI available."}</p>
          <h3>🩺 Physical Exam:</h3>
          <p>{caseData.exam || "No exam available."}</p>
          <h3>🧪 Labs:</h3>
          <div style={{
            padding: '0.25rem 0',
            fontSize: '0.95rem',
            fontFamily: 'Segoe UI, sans-serif',
            lineHeight: '1.6',
            background: 'none',
          }}>
            {renderNestedLab(caseData.labs)}
          </div>
          <h3>🖼️ Imaging:</h3>
          <p>{caseData.imaging || "No imaging available."}</p>
        </div>
        {Array.isArray(decisions) && decisions.length > 0 ? (
          decisions.map((q, idx) => (
            <div key={idx} style={{ marginBottom: '2rem' }}>
              <h4 style={{ fontSize: '1.1rem', fontWeight: 'bold' }}>🧩 {q.question}</h4>
              {q.options && Array.isArray(q.options) && q.options.map((opt, oidx) => {
                const selected = responses[q.question] === opt;
                const isCorrect = opt === q.correct;
                const show = showFeedback[q.question];
                const style = {
                  margin: '0.5rem',
                  padding: '0.5rem 1rem',
                  borderRadius: '5px',
                  border: selected ? '2px solid blue' : '1px solid #ccc',
                  backgroundColor: show && selected ? (isCorrect ? '#c8e6c9' : '#ffcdd2') : ''
                };
                return (
                  <button key={oidx} style={style} onClick={() => handleChoice(q.question, opt)}>
                    {opt}
                  </button>
                );
              })}
              {showFeedback[q.question] && responses[q.question] && (
                <div style={{ marginTop: '0.5rem' }}>
                  {responses[q.question] === q.correct ? (
                    <span style={{ color: 'green' }}>✅ Correct</span>
                  ) : (
                    <span style={{ color: 'red' }}>❌ Incorrect. Correct: {q.correct}</span>
                  )}
                  <div style={{
                    marginTop: '0.5rem',
                    fontStyle: 'italic',
                    color: '#444',
                    backgroundColor: '#f4f4f4',
                    padding: '0.5rem',
                    borderRadius: '0.3rem'
                  }}>
                    Explanation: {safeExplanation(q)}
                  </div>
                </div>
              )}
              {/* Show "Show Answer" button if not revealed, then show answer/explanation after click */}
              {!showAnswer[q.question] ? (
                <button
                  onClick={() => setShowAnswer(prev => ({ ...prev, [q.question]: true }))}
                  style={{
                    marginTop: '0.7rem',
                    padding: '0.5rem 1.1rem',
                    background: '#7c3aed',
                    color: 'white',
                    border: 'none',
                    borderRadius: '7px',
                    fontWeight: 'bold',
                    fontSize: '1em',
                    cursor: 'pointer'
                  }}
                >
                  Show Answer
                </button>
              ) : (
                <div style={{ marginTop: '0.8rem', background: '#f8f9fc', padding: '0.7rem', borderRadius: 6 }}>
                  <b>Correct Answer:</b> {q.correct}<br />
                  <b>Explanation:</b> {q.explanation}
                </div>
              )}
            </div>
          ))
        ) : (
          <p>No decisions/questions available.</p>
        )}

        {!completed && decisions.length > 0 && (
          <button onClick={submitSimulation} style={{ marginTop: '1rem', padding: '0.75rem 1.5rem' }}>
            Submit Case
          </button>
        )}

        {completed && (
          <div style={{ marginTop: '2rem', background: '#eef', padding: '1rem', borderRadius: '8px' }}>
            <h3 style={{ fontWeight: 'bold' }}>📝 Final Summary</h3>
            <p>{safeSummary(caseData)}</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default SimulationSelector;


