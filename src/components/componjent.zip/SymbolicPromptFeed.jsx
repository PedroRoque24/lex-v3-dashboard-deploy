import React, { useEffect, useState } from "react";

export default function SymbolicPromptFeed() {
  const [thought, setThought] = useState("");
  const [isValid, setIsValid] = useState(true);

  useEffect(() => {
    fetch("/memory/brain-thought.txt")
      .then((res) => res.text())
      .then((text) => {
        const trimmed = text.trim();
        const isHTML = trimmed.startsWith("<") || trimmed.includes("<html");
        if (isHTML || trimmed.length === 0 || trimmed.includes("404")) {
          setIsValid(false);
        } else {
          setThought(trimmed);
        }
      })
      .catch(() => {
        setIsValid(false);
      });
  }, []);

  return (
    <div className="bg-white text-black border rounded p-4 shadow">
      <h3 className="text-lg font-semibold mb-2">💭 Latest Symbolic Prompt</h3>
      {isValid && thought && thought !== "(null)" && thought !== "(missing)" ? (
        <p className="whitespace-pre-wrap text-sm italic text-purple-800">{thought}</p>
      ) : (
        <p className="italic text-gray-500">⚠️ No symbolic prompt available yet.</p>
      )}
    </div>
  );
}
