import React, { useState, useEffect } from "react";

const DEFAULT_SNIPPETS = [
  "O paciente encontra-se em boas condições gerais.",
  "Paciente orientado e colaborante.",
];

export default function LibraryEditorSnippets() {
  const [text, setText] = useState("");
  const [snippets, setSnippets] = useState([]);
  const [newSnippet, setNewSnippet] = useState("");

  // Load snippets from localStorage (or fallback to defaults)
  useEffect(() => {
    const saved = localStorage.getItem("custom_snippets");
    setSnippets(saved ? JSON.parse(saved) : DEFAULT_SNIPPETS);
  }, []);

  // Save snippets to localStorage on change
  useEffect(() => {
    localStorage.setItem("custom_snippets", JSON.stringify(snippets));
  }, [snippets]);

  const handleSnippetInsert = (snippet) => {
    setText((prev) => prev + (prev && !prev.endsWith(" ") ? " " : "") + snippet);
  };

  const handleSnippetCopy = (snippet) => {
    navigator.clipboard.writeText(snippet);
  };

  const handleAddSnippet = () => {
    if (!newSnippet.trim()) return;
    setSnippets((prev) => [...prev, newSnippet.trim()]);
    setNewSnippet("");
  };

  const handleDeleteSnippet = (idx) => {
    setSnippets((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleCopyAll = () => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white max-w-xl mx-auto">
      <label className="block text-sm font-medium mb-2">
        Editor de Snippets
      </label>
      <textarea
        className="w-full min-h-[120px] rounded-md border border-gray-300 p-2 mb-4"
        placeholder="Edite ou cole o texto aqui..."
        value={text}
        onChange={e => setText(e.target.value)}
      />

      <div className="mb-4">
        <span className="block text-sm font-semibold mb-1">Snippets rápidos:</span>
        <div className="flex flex-wrap gap-2 mb-2">
          {snippets.map((snippet, i) => (
            <div key={i} className="flex gap-1 items-center">
              <button
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                onClick={() => handleSnippetInsert(snippet)}
                type="button"
              >
                Inserir
              </button>
              <button
                className="bg-gray-400 text-white rounded px-2"
                onClick={() => handleSnippetCopy(snippet)}
                type="button"
                title="Copiar snippet"
              >
                📋
              </button>
              <span className="text-xs bg-gray-100 px-2 py-1 rounded">{snippet}</span>
              <button
                className="ml-1 text-red-600 hover:text-red-900"
                onClick={() => handleDeleteSnippet(i)}
                type="button"
                title="Remover"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            className="border px-2 py-1 rounded"
            placeholder="Novo snippet"
            value={newSnippet}
            onChange={e => setNewSnippet(e.target.value)}
          />
          <button
            className="bg-green-600 text-white px-3 py-1 rounded"
            onClick={handleAddSnippet}
            type="button"
          >
            Adicionar
          </button>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition"
          disabled={!text}
          onClick={() => alert("Texto salvo:\n\n" + text)}
          type="button"
        >
          Salvar Texto
        </button>
        <button
          className="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-800 transition"
          disabled={!text}
          onClick={handleCopyAll}
          type="button"
        >
          📋 Copiar tudo
        </button>
      </div>
    </div>
  );
}
