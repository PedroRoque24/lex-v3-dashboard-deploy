
import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext";

const CompanionEmotionHistoryViewer = () => {
  const { casePath } = useCaseContext();
  const [log, setLog] = useState([]);
  const [expanded, setExpanded] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    if (!casePath) return;
    fetch(`/memory/${casePath}/companion_log.json`)
      .then(res => res.json())
      .then(data => setLog(data.reverse()))
      .catch(() => setLog([]));
  }, [casePath]);

  const visible = expanded ? log : log.slice(0, 2);

  if (hidden) return (
    <div className="mt-4 text-sm">
      <button
        className="px-3 py-1 bg-gray-300 hover:bg-gray-400 text-black rounded"
        onClick={() => setHidden(false)}
      >
        Show Lex Companion Emotional History
      </button>
    </div>
  );

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4 max-w-3xl">
      <h2 className="text-xl font-bold mb-2">🧠 Lex Companion – Emotional History</h2>
      {log.length === 0 ? (
        <p className="text-sm italic text-gray-600">No emotional replies logged yet.</p>
      ) : (
        <>
          <ul className="space-y-4 text-sm">
            {visible.map((entry, i) => (
              <li key={i} className="border rounded p-3 bg-gray-50">
                <p className="text-gray-600 mb-1">🕒 <strong>{new Date(entry.timestamp).toLocaleString()}</strong></p>
                <p className="italic text-blue-700 mb-2">User: "{entry.input}"</p>
                <p className="text-purple-800">🧠 Emotion: <strong>{entry.emotion || "Not tagged"}</strong></p>
                <div className="bg-white p-2 mt-2 border-l-4 border-purple-400">
                  <p className="text-gray-800">Lex: {entry.response || entry.reply}</p>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-4 space-x-2">
            {log.length > 2 && (
              <button
                className="px-3 py-1 bg-purple-200 hover:bg-purple-300 text-purple-800 rounded text-sm"
                onClick={() => setExpanded(!expanded)}
              >
                {expanded ? "Show Less" : "Show More"}
              </button>
            )}
            <button
              className="px-3 py-1 bg-gray-200 hover:bg-gray-300 text-black rounded text-sm"
              onClick={() => setHidden(true)}
            >
              Hide
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default CompanionEmotionHistoryViewer;
