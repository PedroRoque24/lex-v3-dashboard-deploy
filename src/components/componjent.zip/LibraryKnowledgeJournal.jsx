import React, { useState, useEffect } from "react";
import axios from "axios";
import { useCaseContext } from "./CaseContext";

const GLOBAL_KEY = "global_knowledge_journal";

export default function LibraryKnowledgeJournal() {
  const { casePath } = useCaseContext() || {};
  const [journal, setJournal] = useState("");
  const [log, setLog] = useState([]);
  const [globalLog, setGlobalLog] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    setLog([]);
    setError("");
    if (casePath) {
      axios.post("http://localhost:5000/api/journal/get", {
        case_path: casePath
      }).then(res => setLog(res.data || []))
        .catch(() => setError("Failed to load case journal."));
    }
    const globalEntries = localStorage.getItem(GLOBAL_KEY);
    setGlobalLog(globalEntries ? JSON.parse(globalEntries) : []);
  }, [casePath]);

  const handleSave = async () => {
    if (!journal.trim()) return;
    setError("");
    if (casePath) {
      try {
        await axios.post("http://localhost:5000/api/journal/addEntry", {
          case_path: casePath,
          content: journal.trim()
        });
        setJournal("");
        const res = await axios.post("http://localhost:5000/api/journal/get", {
          case_path: casePath
        });
        setLog(res.data || []);
      } catch (e) {
        setError("Failed to save entry to case journal.");
      }
    } else {
      const entry = {
        content: journal.trim(),
        timestamp: new Date().toISOString(),
      };
      const updated = [...globalLog, entry];
      localStorage.setItem(GLOBAL_KEY, JSON.stringify(updated));
      setGlobalLog(updated);
      setJournal("");
    }
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white max-w-xl mx-auto">
      <h2 className="text-lg font-bold mb-2">Knowledge Journal</h2>
      <textarea
        className="w-full min-h-[100px] rounded-md border border-gray-300 p-2 mb-4"
        placeholder="Write your clinical note or learning here..."
        value={journal}
        onChange={e => setJournal(e.target.value)}
      />
      <button
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
        disabled={!journal.trim()}
        onClick={handleSave}
        type="button"
      >
        Save Journal
      </button>
      {error && (
        <div className="mt-2 text-red-600 font-bold">{error}</div>
      )}
      {casePath && (
        <div className="mt-6">
          <h3 className="text-md font-semibold mb-2">Entries for Selected Case</h3>
          <ul className="space-y-2">
            {log.slice().reverse().map((entry, i) => (
              <li key={i} className="bg-gray-100 rounded p-2">
                <div className="text-xs text-gray-500 mb-1">
                  {entry.timestamp ? new Date(entry.timestamp).toLocaleString() : ""}
                </div>
                <div>{entry.content}</div>
              </li>
            ))}
          </ul>
        </div>
      )}
      <div className="mt-6">
        <h3 className="text-md font-semibold mb-2">
          {casePath ? "Global Notes (not tied to a case)" : "Journal Entries"}
        </h3>
        <ul className="space-y-2">
          {globalLog.slice().reverse().map((entry, i) => (
            <li key={i} className="bg-gray-50 rounded p-2">
              <div className="text-xs text-gray-400 mb-1">
                {entry.timestamp ? new Date(entry.timestamp).toLocaleString() : ""}
              </div>
              <div>{entry.content}</div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

