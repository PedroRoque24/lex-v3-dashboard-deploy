import React, { useState } from "react";
import SymbolicPromptFeed from "./SymbolicPromptFeed";
import DreamLexSimViewer from "./DreamLexSimViewer";
import IdentityTimelineChart from "./IdentityTimelineChart";
import TraitDriftChart from "./TraitDriftChart";
import ContradictionViewer from "./ContradictionViewer";
import MemorySymbolicViewer from "./MemorySymbolicViewer";
import LexSimReflections from "./LexSimReflections";
import LivingBrain from "./LivingBrain";

// Matches the symbolic regions in LivingBrain (keep in sync!)
const SECTIONS = [
  { key: "prompt", label: "💭 Prompt", component: SymbolicPromptFeed },
  { key: "dream", label: "🌌 Dreams", component: DreamLexSimViewer },
  { key: "trait_evolution", label: "🧬 Trait Evolution", component: IdentityTimelineChart },
  { key: "trait_drift", label: "🔀 Trait Drift", component: TraitDriftChart },
  { key: "contradictions", label: "⚖️ Contradictions", component: ContradictionViewer },
  { key: "memory", label: "🧠 Memory", component: MemorySymbolicViewer },
  { key: "reflections", label: "🪞 Reflections", component: LexSimReflections }
];

export default function SymbolicMode() {
  // No more tab navigation—use LivingBrain as symbolic navigator!
  const [selected, setSelected] = useState("prompt");

  // Find current section definition/component
  const currentSection = SECTIONS.find(sec => sec.key === selected) || SECTIONS[0];
  const PanelComponent = currentSection.component;

  return (
    <div className="p-8 bg-gradient-to-tr from-purple-50 to-blue-50 min-h-screen">
      <div className="max-w-4xl mx-auto shadow-2xl rounded-2xl bg-white/80 p-6 backdrop-blur border border-purple-100">
        <h1 className="text-4xl font-black text-purple-900 mb-6 tracking-tight flex items-center gap-2">
          🧠 Symbolic Brain Mode
        </h1>

        {/* Living Brain UI — controls section by setSelected */}
        <LivingBrain selected={selected} setSelected={setSelected} />

        {/* Symbolic Panel for current section */}
        <div className="mt-4 min-h-[350px]">
          <PanelComponent />
        </div>
      </div>
    </div>
  );
}

