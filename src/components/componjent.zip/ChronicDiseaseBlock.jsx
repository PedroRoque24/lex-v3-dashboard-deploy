import React, { useEffect, useState } from "react";
import axios from "axios";
import { useCaseContext } from "./CaseContext";

export default function ChronicDiseaseBlock() {
  const { patientId, casePath } = useCaseContext() || {};
  const [diseases, setDiseases] = useState([]);
  const [newDisease, setNewDisease] = useState("");
  const [suggestion, setSuggestion] = useState(null);
  const [isSuggesting, setIsSuggesting] = useState(false);

  useEffect(() => {
    if (!casePath) return;
    axios.post("http://localhost:5000/api/chronic/get", {
      case_path: casePath,
      type: "chronic_diseases.json"
    }).then(res => setDiseases(res.data || []));
  }, [casePath]);

  useEffect(() => {
    if (!newDisease.trim()) {
      setSuggestion(null);
      return;
    }
    setIsSuggesting(true);
    axios.post("http://localhost:5000/api/gpt/icd_suggest", {
      q: newDisease.trim()
    }).then(res => {
      setSuggestion(res.data && res.data.name ? res.data : null);
      setIsSuggesting(false);
    }).catch(() => setIsSuggesting(false));
  }, [newDisease]);

  const addDisease = async () => {
    let entry;
    if (suggestion && suggestion.name) {
      entry = {
        name: suggestion.name,
        icd: suggestion.icd,
        raw: newDisease
      };
    } else {
      entry = { name: newDisease.trim(), icd: "", raw: newDisease.trim() };
    }
    const updated = [...diseases, entry];
    await axios.post("http://localhost:5000/api/chronic/save", {
      case_path: casePath,
      type: "chronic_diseases.json",
      array: updated
    });
    setDiseases(updated);
    setNewDisease("");
    setSuggestion(null);
  };

  const removeDisease = async (i) => {
    const updated = diseases.filter((_, idx) => idx !== i);
    await axios.post("http://localhost:5000/api/chronic/save", {
      case_path: casePath,
      type: "chronic_diseases.json",
      array: updated
    });
    setDiseases(updated);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold flex items-center">🧬 Chronic Conditions</h2>
      <ul className="list-disc ml-6 text-white">
        {diseases.map((d, i) => (
          <li key={i}>
            {typeof d === "string"
              ? d
              : (
                <>
                  <span>{d.name}</span>
                  {d.icd && <span className="ml-2 text-blue-400">[{d.icd}]</span>}
                </>
              )
            }
            <button onClick={() => removeDisease(i)} className="ml-2 text-red-500">remove</button>
          </li>
        ))}
      </ul>
      <div className="flex gap-2 items-center">
        <input
          className="text-black px-2 py-1"
          placeholder="Add condition"
          value={newDisease}
          onChange={(e) => setNewDisease(e.target.value)}
        />
        <button onClick={addDisease} className="bg-blue-600 text-white px-3 py-1 rounded" disabled={!newDisease.trim()}>Add</button>
        {isSuggesting && <span className="ml-2 text-xs text-yellow-300">GPT...</span>}
      </div>
      {suggestion && (
        <div className="ml-2 p-2 rounded bg-blue-950/80 text-xs text-blue-200">
          <b>Suggestion:</b> {suggestion.name} {suggestion.icd && `[${suggestion.icd}]`}
        </div>
      )}
    </div>
  );
}

