import { useCaseContext } from './CaseContext.jsx';
import React, { useState } from "react";

const MedicationInputBlock = () => {
  const { casePath } = useCaseContext();

  const [form, setForm] = useState({
    name: "",
    dose: "",
    frequency_hours: "24",
    start: "",
    end: "",
    source: "patient"
  });

  const [message, setMessage] = useState("");

  const handleSubmit = async () => {
    if (!casePath) {
      setMessage("⚠️ No case selected.");
      return;
    }

    const payload = {
      case_path: casePath,
      ...form
    };

    try {
      const res = await fetch("http://localhost:5000/api/medications/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const result = await res.json();
      if (res.ok) {
        setMessage("✅ Medication saved.");
        setForm({
          name: "",
          dose: "",
          frequency_hours: "24",
          start: "",
          end: "",
          source: "patient"
        });
      } else {
        setMessage("❌ Failed to save: " + (result.message || result.error));
      }
    } catch (err) {
      console.error("API error:", err);
      setMessage("❌ Failed to reach save API.");
    }
  };

  return (
    <div className="p-4 bg-white text-black rounded shadow-md">
      <h2 className="text-xl font-semibold mb-3">💊 Add Medication</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <input className="p-2 rounded border" placeholder="Medication Name" value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="p-2 rounded border" placeholder="Dose (e.g. 5mg)" value={form.dose}
          onChange={(e) => setForm({ ...form, dose: e.target.value })} />
        <input type="number" className="p-2 rounded border" placeholder="Frequency (hours)" value={form.frequency_hours}
          onChange={(e) => setForm({ ...form, frequency_hours: e.target.value })} />
        <input type="date" className="p-2 rounded border" value={form.start}
          onChange={(e) => setForm({ ...form, start: e.target.value })} />
        <input type="date" className="p-2 rounded border" value={form.end}
          onChange={(e) => setForm({ ...form, end: e.target.value })} />
        <select className="p-2 rounded border" value={form.source}
          onChange={(e) => setForm({ ...form, source: e.target.value })}>
          <option value="patient">Patient</option>
          <option value="doctor">Doctor</option>
        </select>
      </div>
      <button
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded"
        onClick={handleSubmit}
      >
        Save Medication
      </button>
      {message && <p className="mt-2 text-sm">{message}</p>}
    </div>
  );
};

export default MedicationInputBlock;