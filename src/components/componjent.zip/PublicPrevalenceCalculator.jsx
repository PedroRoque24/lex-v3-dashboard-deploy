import React, { useState } from "react";

export default function PublicPrevalenceCalculator() {
  const [population, setPopulation] = useState("");
  const [cases, setCases] = useState("");
  const [result, setResult] = useState(null);

  const calculate = () => {
    const pop = parseFloat(population);
    const num = parseFloat(cases);
    if (!pop || !num || pop === 0) return;
    const rate = (num / pop) * 100000;
    setResult(rate.toFixed(2));
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div>
        <h2 className="text-xl font-bold">🧮 Prevalence Calculator</h2>

        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            placeholder="Total Population"
            className="border px-2 py-1 rounded"
            value={population}
            onChange={(e) => setPopulation(e.target.value)}
          />
          <input
            type="number"
            placeholder="Number of Cases"
            className="border px-2 py-1 rounded"
            value={cases}
            onChange={(e) => setCases(e.target.value)}
          />
        </div>

        <button onClick={calculate} disabled={!population || !cases} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
          Calculate Prevalence per 100,000
        </button>

        {result && (
          <div className="mt-4 text-sm text-gray-700">
            Estimated Prevalence: <strong>{result}</strong> cases per 100,000
          </div>
        )}
      </div>
    </div>
  );
}