import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext.jsx";

const MedicationViewer = () => {
  const { casePath } = useCaseContext();
  const [meds, setMeds] = useState([]);

  useEffect(() => {
    if (!casePath) return;

    fetch("http://localhost:5000/api/medications/get", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath })
    })
      .then((res) => res.json())
      .then((data) => setMeds(data))
      .catch((err) => {
        console.error("Failed to fetch meds:", err);
        setMeds([]);
      });
  }, [casePath]);

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4">
      <h2 className="text-xl font-bold mb-2">💊 Active Medications</h2>
      {meds.length === 0 && <p className="text-sm italic">No medications found.</p>}
      <ul className="space-y-2">
        {meds.map((med, i) => (
          <li key={i} className="border-b pb-2">
            <strong>{med.name}</strong> – {med.dose}<br />
            Every {med.frequency_hours}h | Start: {med.start || "–"} | End: {med.end || "–"}<br />
            <span className="text-xs text-gray-500">Source: {med.source}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MedicationViewer;