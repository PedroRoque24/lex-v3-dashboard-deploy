import React, { useState } from "react";
import { useCaseContext } from "./CaseContext";

export default function DownloadPatientReportButton() {
  const { casePath } = useCaseContext();
  const [mode, setMode] = useState("friendly"); // "friendly" or "soap"
  const [sections, setSections] = useState({
    summary: true,
    medications: true,
    timeline: true,
    encouragement: true,
    alerts: true
  });

  const toggleSection = (key) => {
    setSections((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleDownload = () => {
    const patient_id = casePath.split("/")[1];
    const selected = Object.entries(sections)
      .filter(([_, v]) => v)
      .map(([k]) => k);
    const query = new URLSearchParams({
      case_path: casePath,
      patient_id,
      mode: mode,
      sections: JSON.stringify(selected)
    }).toString();
    window.open(`/reportapi/patient/download?${query}`, "_blank");
  };

  return (
    <div className="mb-4 p-3 border rounded bg-gray-50">
      <h3 className="text-sm font-bold mb-2">📋 Patient Report Generator</h3>

      <div className="mb-3">
        <label className="text-sm mr-2 font-medium">📄 Report Type:</label>
        <select
          value={mode}
          onChange={(e) => setMode(e.target.value)}
          className="text-sm p-1 border rounded"
        >
          <option value="friendly">🧠 Friendly (Patient Explanation)</option>
          <option value="soap">🩺 SOAP (Clinical Summary)</option>
        </select>
      </div>

      {mode === "friendly" && (
        <div className="grid grid-cols-2 gap-2 text-sm mb-2">
          {Object.keys(sections).map((key) => (
            <label key={key} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={sections[key]}
                onChange={() => toggleSection(key)}
              />
              {key.charAt(0).toUpperCase() + key.slice(1)}
            </label>
          ))}
        </div>
      )}

      <button
        onClick={handleDownload}
        className="mt-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded text-sm"
      >
        📥 Generate Patient Report
      </button>
    </div>
  );
}