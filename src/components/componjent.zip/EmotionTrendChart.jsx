import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext.jsx";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";

const EmotionTrendChart = () => {
  const { casePath } = useCaseContext();
  const [data, setData] = useState([]);

  useEffect(() => {
    if (!casePath) return;

    fetch(`/memory/${casePath}/emotional_log.json`)
      .then(res => res.json())
      .then(entries => {
        const byDate = {};

        entries.forEach(entry => {
          const date = new Date(entry.timestamp).toISOString().split("T")[0];
          const emotion = entry.gpt_emotion || "unknown";
          if (!byDate[date]) byDate[date] = {};
          byDate[date][emotion] = (byDate[date][emotion] || 0) + 1;
        });

        const structured = Object.entries(byDate).map(([date, counts]) => ({
          date,
          ...counts
        }));

        setData(structured);
      })
      .catch(err => {
        console.error("Failed to load emotion log:", err);
        setData([]);
      });
  }, [casePath]);

  const colors = {
    Anxious: "#f59e0b",
    Stressed: "#ef4444",
    Calm: "#10b981",
    Overwhelmed: "#6366f1",
    unknown: "#6b7280"
  };

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4 max-w-4xl">
      <h2 className="text-xl font-bold mb-3">📊 Emotional Trend Over Time</h2>
      {data.length === 0 ? (
        <p className="text-sm italic text-gray-500">No emotional data available.</p>
      ) : (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis allowDecimals={false} />
            <Tooltip />
            <Legend />
            {Object.keys(colors).map((key) => (
              <Line
                key={key}
                type="monotone"
                dataKey={key}
                stroke={colors[key]}
                name={key}
                dot={false}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
};

export default EmotionTrendChart;