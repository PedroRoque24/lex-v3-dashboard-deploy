import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext";

export default function ReportHistoryViewer() {
  const { casePath } = useCaseContext();
  const [reports, setReports] = useState([]);

  useEffect(() => {
    if (!casePath) return;
    fetch(`/api/report/patient/list?case_path=${casePath}`)
      .then(res => res.json())
      .then(data => setReports(data));
  }, [casePath]);

  return (
    <div className="mt-6 border-t pt-4">
      <h3 className="text-md font-semibold mb-3">📂 Previous Reports</h3>
      {reports.length === 0 ? (
        <p className="text-sm text-gray-500">No reports found for this case.</p>
      ) : (
        <ul className="space-y-3 text-sm">
          {reports.map((r, i) => (
            <li key={i} className="flex items-start justify-between border p-3 rounded bg-white text-black">
              <div>
                <div className="font-semibold">
                  🧠 {r.type} — 👤 {r.patient_id} — 🕒 {r.timestamp}
                </div>
                {r.sections?.length > 0 && (
                  <div className="text-xs text-gray-600">
                    🗂 Sections: {r.sections.map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(", ")}
                  </div>
                )}
                <div className="text-xs text-gray-400 mt-1">{r.filename}</div>
              </div>
              <a
                href={r.url}
                target="_blank"
                rel="noopener noreferrer"
                className="ml-4 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs h-fit"
              >
                📥 Download
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
