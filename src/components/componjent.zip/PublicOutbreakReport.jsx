import React, { useState, useEffect } from "react";

// API helpers
async function loadOutbreakReports() {
  const res = await fetch("/api/public/load", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "outbreak" }),
  });
  const data = await res.json();
  return Array.isArray(data) ? data : [];
}

async function appendOutbreakReport(report) {
  const res = await fetch("/api/public/append", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "outbreak", entry: report }),
  });
  return await res.json();
}

async function clearOutbreakReports() {
  const res = await fetch("/api/public/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ type: "outbreak", data: [] }),
  });
  return await res.json();
}

export default function PublicOutbreakReport() {
  const [disease, setDisease] = useState("");
  const [location, setLocation] = useState("");
  const [cases, setCases] = useState("");
  const [date, setDate] = useState("");
  const [report, setReport] = useState("");
  const [log, setLog] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOutbreakReports().then((saved) => {
      setLog(Array.isArray(saved) ? saved : []);
      setLoading(false);
    });
  }, []);

  const generateReport = async () => {
    const text = `🦠 OUTBREAK ALERT\n\nDisease: ${disease}\nLocation: ${location}\nCases Reported: ${cases}\nDate of Notification: ${date}\n\nHealth authorities are advised to increase surveillance and inform the community.\nFurther investigations are recommended.`;
    setReport(text);
    const entry = {
      timestamp: new Date().toISOString(),
      disease,
      location,
      cases,
      date,
      text,
    };
    setLog((prev) => [...prev, entry]);
    await appendOutbreakReport(entry);
  };

  const clearAll = async () => {
    setLog([]);
    await clearOutbreakReports();
  };

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white mb-4">
      <div>
        <h2 className="text-xl font-bold">📢 Outbreak Report Generator</h2>

        <div className="grid grid-cols-2 gap-2">
          <input
            placeholder="Disease"
            className="border px-2 py-1 rounded"
            value={disease}
            onChange={(e) => setDisease(e.target.value)}
          />
          <input
            placeholder="Location"
            className="border px-2 py-1 rounded"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <input
            type="number"
            placeholder="Case Count"
            className="border px-2 py-1 rounded"
            value={cases}
            onChange={(e) => setCases(e.target.value)}
          />
          <input
            type="date"
            className="border px-2 py-1 rounded"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>

        <button onClick={generateReport} disabled={!disease || !location || !cases || !date} className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
          📝 Generate Report
        </button>

        <button
          className="ml-3 bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition"
          onClick={clearAll}
        >
          🗑️ Clear All
        </button>

        {report && (
          <>
            <textarea
              value={report}
              readOnly
              rows={10}
              className="w-full border rounded p-2 mt-4 text-sm"
            />
            <button
              className="mt-2"
              onClick={() => navigator.clipboard.writeText(report)}
            >
              📋 Copy Report
            </button>
          </>
        )}

        <div className="mt-6">
          <h3 className="font-semibold text-md mb-2">📚 Past Outbreak Reports</h3>
          {loading ? (
            <div>Loading...</div>
          ) : (
            <ul className="text-sm list-decimal ml-5">
              {log.map((entry, idx) => (
                <li key={idx}>
                  <strong>{entry.disease}</strong> ({entry.date}) in {entry.location}: {entry.cases} cases
                  <pre className="bg-gray-100 border rounded p-2 mt-1 whitespace-pre-wrap">{entry.text}</pre>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
