import React, { useEffect, useState } from "react";
import axios from "axios";
import { useCaseContext } from "./CaseContext";

export default function LibraryTimelineNavigator() {
  const { casePath } = useCaseContext() || {};
  const [timeline, setTimeline] = useState([]);
  const [query, setQuery] = useState("");

  // Fetch real continuum_timeline.json
  useEffect(() => {
    if (!casePath) return;
    axios
      .post("http://localhost:5000/api/library/continuum_timeline", { case_path: casePath })
      .then(res => setTimeline(res.data || []));
  }, [casePath]);

  // Filter entries by search query (in summary, content, or source)
  const filtered = timeline.filter((e) => {
    const q = query.trim().toLowerCase();
    return (
      !q ||
      (e.summary && e.summary.toLowerCase().includes(q)) ||
      (e.content && e.content.toLowerCase().includes(q)) ||
      (e.source && e.source.toLowerCase().includes(q))
    );
  });

  return (
    <div className="p-4 rounded-md border border-gray-200 bg-white max-w-xl mx-auto">
      <h2 className="text-lg font-bold mb-2">Timeline Navigator</h2>
      <input
        className="border px-2 py-1 mb-4 rounded w-full"
        placeholder="Buscar (ex: febre, consulta, exame, alta)..."
        value={query}
        onChange={e => setQuery(e.target.value)}
      />
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-gray-400 text-sm">Nenhum evento encontrado.</div>
        ) : (
          filtered.map((e, i) => (
            <div key={i} className="border rounded p-2 bg-gray-50">
              <div className="text-xs text-gray-500 mb-1">
                {e.date ? new Date(e.date).toLocaleString() : ""}
                {e.source && (
                  <span className="ml-2 text-yellow-600">[{e.source}]</span>
                )}
              </div>
              <div className="font-semibold">{e.summary || e.content || "—"}</div>
              {e.detail && <div className="text-xs text-gray-700 mt-1">{e.detail}</div>}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
