import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext";

export default function ExamViewer() {
  const { casePath } = useCaseContext();
  const [logs, setLogs] = useState([]);
  const [curatedSummary, setCuratedSummary] = useState(""); // GPT summary
  const [loadingSummary, setLoadingSummary] = useState(false);
  const [openIndexes, setOpenIndexes] = useState([]);
  const [showSummary, setShowSummary] = useState(true); // NEW: show/hide summary
  const [showRawLogs, setShowRawLogs] = useState(true); // NEW: show/hide raw logs

  // Fetch logs and GPT summary
  const fetchLogs = () => {
    if (!casePath) return;
    fetch("http://localhost:5000/api/exam/log/get", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath })
    })
      .then(res => res.json())
      .then(async data => {
        setLogs(data.reverse());

        // Fetch GPT summary as before
        setCuratedSummary("");
        setLoadingSummary(true);
        try {
          const gptRes = await fetch("http://localhost:5001/api/gpt/curate_exam_log", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ logs: data })
          });
          const gptData = await gptRes.json();
          setCuratedSummary(gptData.summary);
        } catch (e) {
          setCuratedSummary("⚠️ Failed to summarize exams with AI.");
        }
        setLoadingSummary(false);
      })
      .catch(err => {
        console.error("❌ Failed to load exam log:", err);
        setLogs([]);
        setCuratedSummary("");
        setLoadingSummary(false);
      });
  };

  useEffect(() => {
    fetchLogs();
  }, [casePath]);

  useEffect(() => {
    window.addEventListener("examUploaded", fetchLogs);
    return () => window.removeEventListener("examUploaded", fetchLogs);
    // eslint-disable-next-line
  }, [casePath]);

  const toggleIndex = (index) => {
    setOpenIndexes((prev) =>
      prev.includes(index)
        ? prev.filter((i) => i !== index)
        : [...prev, index]
    );
  };

  if (!casePath) {
    return <div className="p-4 text-red-600">⚠️ Select a patient/case to view exams.</div>;
  }

  if (logs.length === 0) {
    return <div className="p-4 text-gray-500 italic">No exams analyzed yet.</div>;
  }

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4">
      <h2 className="text-xl font-bold mb-4">📄 AI-Analyzed Exams</h2>

      {/* Toggles */}
      <div className="mb-2 flex gap-3">
        <button
          onClick={() => setShowSummary(v => !v)}
          className="bg-purple-100 border border-purple-400 px-3 py-1 rounded text-purple-900 hover:bg-purple-200"
        >
          {showSummary ? "Hide" : "Show"} Curated Summary
        </button>
        <button
          onClick={() => setShowRawLogs(v => !v)}
          className="bg-blue-100 border border-blue-400 px-3 py-1 rounded text-blue-900 hover:bg-blue-200"
        >
          {showRawLogs ? "Hide" : "Show"} Raw Reports
        </button>
      </div>

      {/* GPT–curated summary */}
      {showSummary && (
        <div className="mb-4">
          {loadingSummary ? (
            <div className="italic text-purple-700">Summarizing with AI…</div>
          ) : (
            curatedSummary && (
              <div className="mb-4 bg-purple-100 border-l-4 border-purple-400 p-4 rounded">
                <h3 className="text-md font-semibold mb-2 flex items-center gap-2">
                  <span>🧠</span> GPT–Curated Exam Summary
                </h3>
                <div className="text-sm whitespace-pre-line">{curatedSummary}</div>
              </div>
            )
          )}
        </div>
      )}

      {/* Raw log entries */}
      {showRawLogs && (
        <div className="space-y-4">
          {logs.map((entry, idx) => (
            <div key={idx} className="border rounded bg-gray-50 p-3 shadow-sm">
              <div className="flex justify-between items-center text-sm text-gray-700">
                <span>
                  🗓 {new Date(entry.timestamp).toLocaleString()} • <code>{entry.filename}</code>
                </span>
                <button
                  onClick={() => toggleIndex(idx)}
                  className="text-blue-600 hover:underline text-xs"
                >
                  {openIndexes.includes(idx) ? "🔽 Hide Report" : "📝 Open Report"}
                </button>
              </div>

              {openIndexes.includes(idx) && (
                <div className="mt-3 space-y-3 text-sm whitespace-pre-wrap">
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-1">🧠 Vision Output</h3>
                    <div>{entry.vision_output}</div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-blue-800 mb-1">⚖️ Lex Reflection</h3>
                    <div>{entry.reflection_output}</div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

