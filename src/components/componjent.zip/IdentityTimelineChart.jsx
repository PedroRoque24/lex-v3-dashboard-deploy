
import React, { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function IdentityTimelineChart() {
  const [data, setData] = useState([]);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetch("/memory/memory-core.json")
      .then(res => res.json())
      .then(json => {
        const timeline = json.identity_timeline ?? {};
        const processed = Object.entries(timeline).map(([key, entry]) => {
          const traits = entry?.trait_update ?? {};
          const total = Object.values(traits).reduce((a, b) => a + b, 0);
          const avg = total / (Object.keys(traits).length || 1);
          return {
            id: key,
            timestamp: entry?.timestamp
              ? new Date(entry.timestamp).toISOString().split("T")[0]
              : "(no time)",
            traits_count: Object.keys(traits).length,
            trait_avg: +avg.toFixed(3)
          };
        });
        setData(processed);
      })
      .catch(err => {
        console.error("Failed to load identity timeline:", err);
        setError(true);
      });
  }, []);

  return (
    <div className="p-4 bg-white text-black rounded shadow">
      <h2 className="text-lg font-bold mb-2">🧬 Trait Evolution Chart</h2>
      {error && (
        <p className="text-sm italic text-red-600">⚠️ Could not load identity timeline.</p>
      )}
      {!error && data.length === 0 && (
        <p className="text-sm italic text-gray-500">No identity timeline entries found.</p>
      )}
      {!error && data.length > 0 && (
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="timestamp" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" domain={[0, 1]} />
            <Tooltip />
            <Legend />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="traits_count"
              stroke="#8884d8"
              name="Traits"
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="trait_avg"
              stroke="#82ca9d"
              name="Avg Score"
            />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
