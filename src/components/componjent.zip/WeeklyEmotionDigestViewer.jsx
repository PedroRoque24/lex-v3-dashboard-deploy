import React, { useEffect, useState } from "react";
import { useCaseContext } from "./CaseContext.jsx";

const WeeklyEmotionDigestViewer = () => {
  const { casePath } = useCaseContext();
  const [text, setText] = useState("");

  useEffect(() => {
    if (!casePath) return;

    fetch("http://localhost:5000/api/emotion_weekly_digest", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ case_path: casePath })
    })
      .then((res) => res.json())
      .then((data) => {
        setText(data.text);
      })
      .catch((err) => {
        console.error("Digest error:", err);
        setText("⚠️ Digest backend returned HTML or malformed data.");
      });
  }, [casePath]);

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4 max-w-3xl">
      <h2 className="text-xl font-bold mb-2">📅 Weekly Emotional Digest</h2>
      <p className="text-sm whitespace-pre-line">{text || "Generating digest..."}</p>
    </div>
  );
};

export default WeeklyEmotionDigestViewer;