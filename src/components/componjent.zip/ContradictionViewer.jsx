import React, { useEffect, useState } from "react";

export default function ContradictionViewer() {
  const [conflict, setConflict] = useState(null);

  useEffect(() => {
    fetch("/memory/contradictions.json")
      .then((res) => res.json())
      .then((data) => {
        // Only use latest non-empty conflict
        const latest = (data || []).slice().reverse().find(item =>
          item.conflict && item.conflict !== "(missing)" && item.conflict !== "(unspecified)"
        );
        setConflict(latest || null);
      })
      .catch(() => setConflict(null));
  }, []);

  return (
    <div className="p-4 rounded-xl shadow bg-white text-black space-y-4">
      <h2 className="text-xl font-bold text-red-700">⚔️ Symbolic Contradiction</h2>
      {!conflict ? (
        <p className="text-gray-500 italic">No contradictions detected.</p>
      ) : (
        <div className="border border-gray-300 rounded-lg p-3 bg-gray-50 shadow-sm">
          <p><strong>Conflict:</strong> {conflict.conflict}</p>
          <p><strong>Source A:</strong> {conflict.sourceA && conflict.sourceA !== "(missing)" ? conflict.sourceA : "Not specified"}</p>
          <p><strong>Source B:</strong> {conflict.sourceB && conflict.sourceB !== "(missing)" ? conflict.sourceB : "Not specified"}</p>
          <p className="text-sm text-gray-600 mt-1">🕒 {conflict.timestamp || "Unknown time"}</p>
        </div>
      )}
    </div>
  );
}

