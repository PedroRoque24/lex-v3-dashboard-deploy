import React, { useEffect, useState } from "react";

// Fetch active problems log (from backend or static)
async function fetchActiveProblems(casePath) {
  const url = `/memory/${casePath}/active_problems.json`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    return await res.json();
  } catch {
    return [];
  }
}

// This will hit the backend every time a problem is solved
async function markProblemSolvedBackend(casePath, icd, summary) {
  // PATCH: Use full backend URL for local dev
  console.log("CALLING /api/problems/mark_solved", { casePath, icd, summary });
  try {
    await fetch("http://localhost:5000/api/problems/mark_solved", {  // PATCHED LINE
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: casePath, icd, summary }),
    });
  } catch (err) {
    // Silently ignore backend failure, so UI is always responsive
    console.error("FAILED to mark as solved", err);
  }
}

function getSolvedICDsLocal(casePath) {
  try {
    const saved = localStorage.getItem(`solved_problems_${casePath}`);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}
function saveSolvedICDsLocal(casePath, arr) {
  localStorage.setItem(`solved_problems_${casePath}`, JSON.stringify(arr));
}

// Smarter: Extract DISEASE only from a verbose summary
function extractDisease(summary = "") {
  if (!summary) return "";
  // 1. Try classic "suggestive of ..." or "diagnosed with ..." style
  let match =
    summary.match(/suggestive of ([A-Za-z0-9\s\-\(\)\/]+)(\.|\)|$)/i) ||
    summary.match(/diagnosed with ([A-Za-z0-9\s\-\(\)\/]+)(\.|\)|$)/i) ||
    summary.match(/consistent with ([A-Za-z0-9\s\-\(\)\/]+)(\.|\)|$)/i) ||
    summary.match(/for ([A-Za-z0-9\s\-\(\)\/]+)(\.|\)|$)/i);

  if (match && match[1]) {
    return match[1].replace(/^(an?|the)\s+/i, "").replace(/\.$/, "").trim();
  }

  // 2. Try extracting last parenthesis group (common for disease)
  let parenMatch = summary.match(/\(([A-Za-z0-9\s\-/]+)\)/);
  if (parenMatch && parenMatch[1]) {
    return parenMatch[1].trim();
  }

  // 3. Fallback: return last 3 words if includes a disease word
  let diseaseWords = [
    "infection", "syndrome", "diabetes", "hypertension", "asthma",
    "pneumonia", "cancer", "disease", "fracture", "injury", "ulcer", "failure"
  ];
  let lastWords = summary.trim().split(/\s+/).slice(-4).join(" ");
  for (let dw of diseaseWords) {
    if (lastWords.toLowerCase().includes(dw)) return lastWords;
  }

  // 4. Last resort
  return "Diagnosis not found";
}

export default function ActiveProblemsPanel({ casePath }) {
  const [problems, setProblems] = useState([]);
  const [solvedICDs, setSolvedICDs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!casePath) return;
    setLoading(true);
    fetchActiveProblems(casePath)
      .then(setProblems)
      .finally(() => setLoading(false));
    setSolvedICDs(getSolvedICDsLocal(casePath));
  }, [casePath]);

  // PATCH: Add debug log to button handler
  const handleSolve = (icd, summary = "") => {
    console.log("MARKING SOLVED", { casePath, icd, summary }); // PATCH: debug
    if (!solvedICDs.includes(icd)) {
      const next = [...solvedICDs, icd];
      setSolvedICDs(next);
      saveSolvedICDsLocal(casePath, next);
      markProblemSolvedBackend(casePath, icd, summary);
    }
  };

  return (
    <div className="p-4 bg-white rounded shadow mb-4">
      <h2 className="text-xl font-bold mb-3 flex items-center">
        <span className="mr-2">🩺</span> Active Problems
      </h2>
      {loading ? (
        <div>Loading...</div>
      ) : problems.length === 0 ? (
        <div>No active problems found for this case.</div>
      ) : (
        <ul className="space-y-4">
          {problems.map((prob, idx) => {
            const isSolved = solvedICDs.includes(prob.icd);
            return (
              <li
                key={idx}
                className={`p-3 rounded border flex flex-col bg-gray-50 shadow-sm relative transition-all duration-300 ${
                  isSolved ? "opacity-50 line-through" : ""
                }`}
              >
                <div className="flex items-center mb-2">
                  <span className="text-xl mr-2">🏷️</span>
                  <span className="text-lg font-bold">
                    {prob.name || extractDisease(prob.summary) || "(No diagnosis found)"}
                  </span>
                </div>
                <div className="ml-7 mb-1">
                  <span className="inline-block px-2 py-1 bg-purple-100 text-purple-800 text-sm rounded">
                    ICD: {prob.icd}
                  </span>
                </div>
                {prob.timestamp && (
                  <div className="ml-7 text-xs text-gray-500 mb-2 flex items-center">
                    <span className="mr-1">📅</span>
                    {new Date(prob.timestamp).toLocaleString()}
                  </div>
                )}
                <div className="ml-7 mt-1">
                  {!isSolved && (
                    <button
                      className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 text-xs rounded hover:bg-green-200 transition"
                      onClick={() => handleSolve(prob.icd, prob.summary || prob.name)}
                    >
                      <span role="img" aria-label="check" className="mr-1">✅</span>
                      Mark as Solved
                    </button>
                  )}
                  {isSolved && (
                    <span className="inline-flex items-center px-2 py-1 bg-gray-200 text-gray-700 text-xs rounded">
                      <span role="img" aria-label="solved" className="mr-1">✔️</span>
                      Solved
                    </span>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
