import React, { useState, useRef } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// Universal helper: find questions array in any shape (quiz, quizze, etc)
function findQuestions(obj) {
  if (!obj || typeof obj !== "object") return [];
  if (Array.isArray(obj)) return obj;
  if (Array.isArray(obj.questions)) return obj.questions;
  for (const key of Object.keys(obj)) {
    if (key.toLowerCase().includes("quiz") && obj[key] && Array.isArray(obj[key].questions))
      return obj[key].questions;
  }
  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === "object") {
      const found = findQuestions(obj[key]);
      if (found.length) return found;
    }
  }
  return [];
}

function extractTopic(obj) {
  if (!obj) return "Quiz";
  if (obj.topic) return obj.topic;
  for (const key of Object.keys(obj)) {
    if (typeof obj[key] === "object" && obj[key].topic) return obj[key].topic;
  }
  return "Quiz";
}

function QuizSelector({ quizData }) {
  const panelRef = useRef(null);

  const questions = findQuestions(quizData);
  const topic = extractTopic(quizData);

  if (!questions.length) return <div>No quiz data available.</div>;

  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [showExplanation, setShowExplanation] = useState({});

  const handleAnswer = (qIndex, option) => {
    setSelectedAnswers(prev => ({ ...prev, [qIndex]: option }));
  };

  const toggleExplanation = (qIndex) => {
    setShowExplanation(prev => ({ ...prev, [qIndex]: !prev[qIndex] }));
  };

  // PDF Download Handler
  const handleDownloadPDF = async () => {
    const element = panelRef.current;
    const canvas = await html2canvas(element, { scale: 2, useCORS: true });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: [canvas.width, canvas.height]
    });
    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
    pdf.save(
      `quiz_${topic.replace(/\s+/g, "_")}_${new Date().toISOString().slice(0, 10)}.pdf`
    );
  };

  return (
    <div>
      <div style={{ textAlign: 'right', marginBottom: '1em' }}>
        <button
          onClick={handleDownloadPDF}
          style={{
            background: '#7c3aed', color: 'white', padding: '0.6em 1.3em', borderRadius: '7px',
            border: 'none', fontWeight: 'bold', fontSize: '1.07em', cursor: 'pointer'
          }}
        >
          Download as PDF
        </button>
      </div>
      <div ref={panelRef} style={{ padding: '1rem' }}>
        {questions.map((q, idx) => (
          <div key={idx} style={{ marginBottom: '2rem' }}>
            <h3>❓ {q.question}</h3>
            <div>
              {q.options && Object.entries(q.options).map(([letter, opt], oidx) => (
                <button
                  key={oidx}
                  onClick={() => handleAnswer(idx, letter)}
                  style={{
                    margin: '0.5rem',
                    padding: '0.5rem 1rem',
                    border: selectedAnswers[idx] === letter ? '2px solid blue' : '1px solid #ccc',
                    borderRadius: '5px'
                  }}
                >
                  {letter}: {opt}
                </button>
              ))}
            </div>
            {selectedAnswers[idx] && (
              <div style={{ marginTop: '0.5rem' }}>
                {selectedAnswers[idx] === q.correct ? (
                  <div style={{ color: 'green' }}>✅ Correct!</div>
                ) : (
                  <div style={{ color: 'red' }}>❌ Incorrect. Correct Answer: {q.correct}</div>
                )}
                <button onClick={() => toggleExplanation(idx)}>
                  {showExplanation[idx] ? "Hide Explanation" : "Show Explanation"}
                </button>
                {showExplanation[idx] && (
                  <div style={{ marginTop: '0.5rem', background: '#eef', padding: '0.5rem' }}>
                    {q.explanation}
                  </div>
                )}
              </div>
            )}
            {/* Always show correct answer and explanation in PDF (for offline) */}
            <div style={{ marginTop: '0.8rem', background: '#f8f9fc', padding: '0.7rem', borderRadius: 6 }}>
              <b>Correct Answer:</b> {q.correct}<br />
              <b>Explanation:</b> {q.explanation}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default QuizSelector;
