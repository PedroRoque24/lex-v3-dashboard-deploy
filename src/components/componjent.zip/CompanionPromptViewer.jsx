
import { useCaseContext } from './CaseContext.jsx';
import React, { useEffect, useState } from 'react';

function CompanionPromptViewer() {
  const context = useCaseContext();
  const [prompts, setPrompts] = useState([]);
  const [error, setError] = useState("");
  const [newPrompt, setNewPrompt] = useState("");
  const [expanded, setExpanded] = useState(false);

  const fetchPrompts = () => {
    if (!context?.casePath) return;
    fetch("http://127.0.0.1:5000/api/companion_prompts/get", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_path: context.casePath })
    })
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) setPrompts(data.reverse());
        else setError("⚠️ Failed to load prompts.");
      })
      .catch((err) => {
        console.error(err);
        setError("❌ Connection error.");
      });
  };

  useEffect(() => {
    fetchPrompts();
  }, [context]);

  const sendPrompt = () => {
    if (!newPrompt.trim()) return;
    fetch("http://127.0.0.1:5000/api/companion_prompts/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: newPrompt, case_path: context.casePath })
    })
      .then(res => res.json())
      .then(() => {
        setNewPrompt("");
        fetchPrompts();
      });
  };

  const visible = expanded ? prompts : prompts.slice(0, 2);

  if (!context) return <div>Loading context...</div>;

  return (
    <div className="p-4 bg-white text-black rounded shadow mt-4 max-w-3xl">
      <h2 className="text-xl font-bold mb-2">🗣️ Lex Companion Prompt History</h2>
      <p className="text-sm text-gray-500 mb-4">Path: <code>{context.casePath}</code></p>

      <div className="mb-4">
        <textarea
          rows={3}
          value={newPrompt}
          onChange={(e) => setNewPrompt(e.target.value)}
          placeholder="How are you feeling? Write here..."
          className="w-full border border-gray-300 p-2 rounded text-sm"
        />
        <button
          onClick={sendPrompt}
          className="mt-2 px-4 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded text-sm"
        >
          Submit Prompt
        </button>
      </div>

      {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
      {prompts.length === 0 && !error ? (
        <p className="italic text-sm text-gray-600">No prompts found.</p>
      ) : (
        <>
          <ul className="space-y-4 text-sm">
            {visible.map((entry, index) => (
              <li key={index} className="border rounded p-3 bg-gray-50">
                <p className="text-gray-600 text-xs mb-1">🕒 {new Date(entry.timestamp).toLocaleString()}</p>
                <p className={entry.sender === "user" ? "text-blue-700" : "text-purple-800"}>
                  <strong>{entry.sender === "user" ? "🧍 You:" : "🧠 Lex:"}</strong> {entry.message}
                </p>
              </li>
            ))}
          </ul>
          {prompts.length > 2 && (
            <button
              className="mt-4 px-3 py-1 bg-purple-200 hover:bg-purple-300 text-purple-800 rounded text-sm"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded ? "Show Less" : "Show More"}
            </button>
          )}
        </>
      )}
    </div>
  );
}

export default CompanionPromptViewer;
