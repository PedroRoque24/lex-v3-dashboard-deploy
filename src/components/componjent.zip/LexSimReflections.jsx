import React, { useEffect, useState } from "react";

export default function LexSimReflections() {
  const [reflection, setReflection] = useState(null);

  useEffect(() => {
    fetch("/memory/reflection-log.txt")
      .then((res) => res.text())
      .then((text) => {
        const lines = text.split(/\r?\n/).filter(line => line.includes("Reflected on"));
        const parsed = lines.map(line => {
          const timeMatch = line.match(/\[(.*?)\]/);
          const topicMatch = line.match(/'(.+?)'/);
          const scoreMatch = line.match(/clarity score (\d+\.\d+)/);
          return {
            timestamp: timeMatch ? timeMatch[1] : null,
            topic: topicMatch ? topicMatch[1] : null,
            clarity: scoreMatch ? parseFloat(scoreMatch[1]) : null
          };
        });
        // Use latest valid
        const latest = parsed.reverse().find(r => r.topic && r.topic !== "(unknown)");
        setReflection(latest || null);
      })
      .catch(() => setReflection(null));
  }, []);

  return (
    <div className="p-4 rounded-xl shadow bg-white text-black space-y-4">
      <h2 className="text-xl font-bold text-yellow-700">🪞 Latest LexSim Reflection</h2>
      {!reflection ? (
        <p className="italic text-gray-500">No LexSim reflections available.</p>
      ) : (
        <div className="border border-yellow-200 bg-yellow-50 p-3 rounded shadow-sm">
          <p className="text-sm text-gray-600 mb-1">🕒 {reflection.timestamp || "Unknown time"}</p>
          <p><strong>🧠 Topic:</strong> {reflection.topic}</p>
          <p><strong>✨ Clarity:</strong> {reflection.clarity ?? "Not specified"}</p>
        </div>
      )}
    </div>
  );
}


